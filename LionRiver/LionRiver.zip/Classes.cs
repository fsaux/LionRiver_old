﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.IO;
using System.ComponentModel;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Data;
using System.Globalization;
using System.Windows.Controls;
using System.Configuration;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

using OSGeo.GDAL;
using OSGeo.OSR;

namespace LionRiver
{
    public class Map
    {
        // Holds Map information
        private Dataset ds;
        private SpatialReference sr;    // Map projected coordinate system
        private SpatialReference wgs84; // Lat/Lon geographical coordinate system
        private CoordinateTransformation transform_to_latlon;
        private CoordinateTransformation transform_from_latlon;
        private double[] gtCoef = new double[6];
        private double[] invCoef = new double[6];

        public BitmapSource Image;

        public double MinLat;
        public double MinLon;
        public double MaxLat;
        public double MaxLon;

        public Map(string filename)
        {


            // Read dataset & raster band
            ds = Gdal.Open(filename, Access.GA_ReadOnly);

            Band band = ds.GetRasterBand(1);

            //string[] meta = ds.GetMetadataItem("BSB_KNP","").Split(',');

            //foreach(string s in meta)
            //    if(s.Substring(0,3)=="DY=")
            //        Scale=Convert.ToDouble(s.Substring(3));


            // Read projected coordinate system and create 
            sr = new SpatialReference(ds.GetProjectionRef());
            string wkt;
            Osr.GetWellKnownGeogCSAsWKT("WGS84", out wkt);
            wgs84 = new SpatialReference(wkt);

            transform_to_latlon = new CoordinateTransformation(sr, wgs84);
            transform_from_latlon = new CoordinateTransformation(wgs84, sr);

            // Read Geo Transform coefficients from dataset and calculate inverse
            ds.GetGeoTransform(gtCoef);
            Gdal.InvGeoTransform(gtCoef, invCoef);

            int width = band.XSize;
            int height = band.YSize;
            System.Windows.Media.PixelFormat pf = System.Windows.Media.PixelFormats.Indexed8;
            int stride = width * pf.BitsPerPixel / 8;

            byte[] pixels = new byte[width * height];

            if (band.GetRasterColorInterpretation() == ColorInterp.GCI_PaletteIndex)
            {
                band.ReadRaster(0, 0, width, height, pixels, width, height, 0, 0);
                ColorTable ct = band.GetRasterColorTable();

                List<Color> colors = new List<Color>();

                for (int i = 0; i < ct.GetCount(); i++)
                {
                    ColorEntry entry = ct.GetColorEntry(i);
                    colors.Add(Color.FromRgb(Convert.ToByte(entry.c1), Convert.ToByte(entry.c2), Convert.ToByte(entry.c3)));
                }

                BitmapPalette palette = new BitmapPalette(colors);

                Image = BitmapSource.Create(width, height, 96, 96, pf, palette, pixels, stride);
            }
            this.ConvertToLL(0, Image.PixelHeight, out MinLon, out MinLat);
            this.ConvertToLL(Image.PixelWidth, 0, out MaxLon, out MaxLat);
        }

        public void ConvertToXY(double lon, double lat, out double x, out double y)
        {
            double[] v = new double[3];
            transform_from_latlon.TransformPoint(v, lon, lat, 0);
            Gdal.ApplyGeoTransform(invCoef, v[0], v[1], out x, out y);
        }

        public void ConvertToLL(double x, double y, out double lon, out double lat)
        {
            double[] v = new double[3];
            double x1, y1;
            Gdal.ApplyGeoTransform(gtCoef, x, y, out  x1, out y1);
            transform_to_latlon.TransformPoint(v, x1, y1, 0);
            lon = v[0];
            lat = v[1];
        }
    }

    public class uvpair
    {
        public double u { get; set; }
        public double v { get; set; }
        public double Lat { get; set; }
        public double Lon { get; set; }
    }

    public class windband
    {
        public DateTime datetime { get; set; }
        public uvpair[,] data;

        public windband(int sizex, int sizey)
        {
            data = new uvpair[sizex, sizey];
        }
    }

    public class windgrib
    {
        private CoordinateTransformation transform_to_latlon;
        private CoordinateTransformation transform_from_latlon;
        private double[] gtCoef = new double[6];
        private double[] invCoef = new double[6];

        public int SizeX;
        public int SizeY;

        public double MinLat;
        public double MinLon;
        public double MaxLat;
        public double MaxLon;

        public Collection<windband> windbands;

        public windgrib(ref Dataset ds)
        {
            SpatialReference sr;    // Map projected coordinate system
            SpatialReference wgs84; // Lat/Lon geographical coordinate system

            sr = new SpatialReference(ds.GetProjectionRef());
            string wkt;
            Osr.GetWellKnownGeogCSAsWKT("WGS84", out wkt);
            wgs84 = new SpatialReference(wkt);

            transform_to_latlon = new CoordinateTransformation(sr, wgs84);
            transform_from_latlon = new CoordinateTransformation(wgs84, sr);

            // Read Geo Transform coefficients from dataset and calculate inverse
            ds.GetGeoTransform(gtCoef);
            Gdal.InvGeoTransform(gtCoef, invCoef);

            SizeX = ds.RasterXSize;
            SizeY = ds.RasterYSize;

            this.ConvertToLL(0, SizeY - 1, out MinLon, out MinLat);
            this.ConvertToLL(SizeX - 1, 0, out MaxLon, out MaxLat);

            MinLat = MinLat > 180 ? MinLat-360 : MinLat;
            MinLon = MinLon > 180 ? MinLon-360 : MinLon;
            MaxLat = MaxLat > 180 ? MaxLat-360 : MaxLat;
            MaxLon = MaxLon > 180 ? MaxLon-360 : MaxLon;

            windbands = new Collection<windband>();
        }

        public void ConvertToXY(double lon, double lat, out double x, out double y)
        {
            double[] v = new double[3];
            transform_from_latlon.TransformPoint(v, lon, lat, 0);
            Gdal.ApplyGeoTransform(invCoef, v[0], v[1], out x, out y);
        }

        public void ConvertToLL(double x, double y, out double lon, out double lat)
        {
            double[] v = new double[3];
            double x1, y1;
            Gdal.ApplyGeoTransform(gtCoef, x, y, out  x1, out y1);
            transform_to_latlon.TransformPoint(v, x1, y1, 0);
            lon = v[0];
            lat = v[1];
        }

        public bool GetWind(double lat, double lon, DateTime dt, out uvpair uv)    
        {
            uv = new uvpair();

            double omega_step = (MaxLon - MinLon) / (SizeX - 1);
            double phi_step = (MaxLat - MinLat) / (SizeY - 1);

            double delta_omega = lon - MinLon;
            double delta_phi = lat - MinLat;

            int i = Convert.ToInt16(delta_omega / omega_step);
            int j = Convert.ToInt16(delta_phi / phi_step);
            
            if ((i >= (SizeX - 1)) || (j >= (SizeY - 1)) || i < 0 || j < 0)
            {
                return false; // Out of the grid
            }

            int idx = 0;
            while (windbands[idx].datetime <= dt)
            {
                idx++;
                if (idx > windbands.Count-1)
                    return false;
            }

            if (idx == 0)
                return false; // Required time not covered in windbands

            // Invert Y axis for NE orientation instead for SE
            j = SizeY - j - 1;

            double tspan = (windbands[idx].datetime - windbands[idx - 1].datetime).TotalSeconds;
            double t = (dt - windbands[idx - 1].datetime).TotalSeconds;

            uvpair uv0 = new uvpair();
            uvpair uv1 = new uvpair();

            GetWindByIndex(lat, lon, i, j, idx - 1, out uv0);
            GetWindByIndex(lat, lon, i, j, idx, out uv1);

            uv.u = uv0.u + (uv1.u - uv0.u) * t / tspan;
            uv.v = uv0.v + (uv1.v - uv0.v) * t / tspan;
            uv.Lat = lat;
            uv.Lon = lon;
            
            return true;
        }

        private void  GetWindByIndex(double lat, double lon, int i,int j, int windband_idx, out uvpair uv)
        {
            uv = new uvpair();

            double x0 = this.windbands[windband_idx].data[i, j].Lon;
            double x1 = this.windbands[windband_idx].data[i+1, j].Lon;
            double y0 = this.windbands[windband_idx].data[i, j].Lat;
            double y1 = this.windbands[windband_idx].data[i , j-1].Lat;
            
            double u00 = this.windbands[windband_idx].data[i, j].u;
            double u10 = this.windbands[windband_idx].data[i + 1, j].u;
            double u01 = this.windbands[windband_idx].data[i, j - 1].u;
            double u11 = this.windbands[windband_idx].data[i + 1, j - 1].u;
                        
            double ua = u00 + (u10 - u00) * (lon - x0) / (x1 - x0);
            double ub = u01 + (u11 - u01) * (lon - x0) / (x1 - x0);

            uv.u = ua + (ub - ua) * (lat - y0) / (y1 - y0);            

            double v00 = this.windbands[windband_idx].data[i, j].v;
            double v10 = this.windbands[windband_idx].data[i + 1, j].v;
            double v01 = this.windbands[windband_idx].data[i, j - 1].v;
            double v11 = this.windbands[windband_idx].data[i + 1, j - 1].v;

            double va = v00 + (v10 - v00) * (lon - x0) / (x1 - x0);
            double vb = v01 + (v11 - v01) * (lon - x0) / (x1 - x0);

            uv.v = va + (vb - va) * (lat - y0) / (y1 - y0);            

        }

    }

    public class ChartData
    {
        public DateTime Time { get; set; }
        public double Val { get; set; }
    }

    public class ChartDataCollection : ObservableCollection<ChartData>
    {
        public const int MaxSize = 600;
    }

    public class Instrument : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;

        protected double _val;
        protected double _average;
        protected int _averagewindow;
        protected CircularBuffer<double> buffer;
        protected CircularBuffer<double> tmpbuf;   // Holds temp data until PushChartData is called
        protected bool _valid;
        protected string _displayname, _units, _FormattedValue;
        protected bool _plot;
        public ChartDataCollection LongBuffer;
        public double LongAverage { get; set; }

        public Instrument(string dn, string un, int aw, bool plot)
        {
            this._displayname = dn;
            this._units = un;
            this._averagewindow = aw;
            this.buffer = new CircularBuffer<double>(120, true);
            this.tmpbuf = new CircularBuffer<double>(120, true);
            this._plot = plot;
            if (_plot)
                this.LongBuffer = new ChartDataCollection();
        }

        public Instrument(string dn, string un, int aw)
            : this(dn, un, aw, false)
        { }

        public Instrument()
            : this("Dummy", "Dummy", 0)
        { }

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        public virtual double Val
        {
            get { return _val; }
            set { _val = value; }
        }

        public string DisplayName
        {
            get { return _displayname; }
            set
            {
                _displayname = value;
            }
        }

        public string Units
        {
            get { return _units; }
            set
            {
                _units = value;
            }
        }

        public string FormattedValue
        {
            get { return _FormattedValue; }
            set
            {
                _FormattedValue = value;
            }
        }

        public void SetValid()
        {
            FormatValue();
            buffer.Put(_val);
            tmpbuf.Put(_val);
            _average = CalculateAverage();
            _valid = true;
            OnPropertyChanged("FormattedValue");
        }

        public void Invalidate()
        {
            _FormattedValue = "";
            _valid = false;
            OnPropertyChanged("FormattedValue");
        }

        public bool IsValid()
        {
            return _valid;
        }

        public double Average()
        {
            return _average;
        }

        protected virtual double CalculateAverage(ref CircularBuffer<double> b, int aw)
        {
            return 0;
        }

        protected virtual double CalculateAverage()
        {
            return CalculateAverage(ref buffer, _averagewindow);
        }

        protected virtual void FormatValue()
        {

        }

        public virtual void PushChartData()
        {
            if (_plot && tmpbuf.Size != 0)
            {
                double avg = CalculateAverage(ref tmpbuf, tmpbuf.Size);
                DateTime tm = DateTime.Now;

                LongBuffer.Add(new ChartData { Time = tm, Val = avg });
                if (LongBuffer.Count() > ChartDataCollection.MaxSize)
                    LongBuffer.RemoveAt(0);
                tmpbuf.Clear();
                this.LongAverage = avg;
            }
        }
    }

    public class LinearInstrument : Instrument
    {
        public LinearInstrument(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        public LinearInstrument(string dn, string un, int aw)
            : base(dn, un, aw)
        {
        }

        protected override double CalculateAverage(ref CircularBuffer<double> b, int aw)
        {
            int size = aw > b.Size ? b.Size : aw;

            double sum = 0;
            for (int i = 0; i < size; i++)
                sum += b.Read(i);
            return sum / size;
        }

        protected override void FormatValue()
        {
            _FormattedValue = _average.ToString("0.00");
        }

    }

    class AngularInstrumentAbs : Instrument
    {
        public AngularInstrumentAbs(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        public AngularInstrumentAbs(string dn, string un, int aw)
            : base(dn, un, aw)
        {
        }

        public override double Val
        {
            get { return _val; }
            set
            {
                _val = Math.Abs((value + 360) % 360);
            }
        }

        protected override double CalculateAverage(ref CircularBuffer<double> b, int aw)
        {
            int size = aw > b.Size ? b.Size : aw;

            double sumcos = 0, sumsin = 0;
            for (int i = 0; i < size; i++)
            {
                double v = b.Read(i);
                sumcos += Math.Cos(v * Math.PI / 180);
                sumsin += Math.Sin(v * Math.PI / 180);
            }
            return ((Math.Atan2(sumsin, sumcos) * 180 / Math.PI) + 360) % 360;
        }

        protected override void FormatValue()
        {
            _FormattedValue = _average.ToString("000");
        }
    }

    class AngularInstrumentRel : Instrument
    {
        public AngularInstrumentRel(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        public AngularInstrumentRel(string dn, string un, int aw)
            : base(dn, un, aw)
        {
        }

        public override double Val
        {
            get { return _val; }
            set
            {
                if (value <= 180)
                    _val = value;
                else
                    _val = value - 360;
            }
        }


        protected override double CalculateAverage(ref CircularBuffer<double> b, int aw)
        {
            int size = aw > b.Size ? b.Size : aw;

            double sumcos = 0, sumsin = 0;
            for (int i = 0; i < size; i++)
            {
                double v = b.Read(i);
                sumcos += Math.Cos(v * Math.PI / 180);
                sumsin += Math.Sin(v * Math.PI / 180);
            }
            return Math.Atan2(sumsin, sumcos) * 180 / Math.PI;
        }

        protected override void FormatValue()
        {
            _FormattedValue = _average.ToString("#");
        }
    }

    class PositionInstrument : Instrument
    {
        public PositionInstrument(string dn, string un, int aw)
            : base(dn, un, aw, false)
        {
        }

        public PositionInstrument(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        protected override double CalculateAverage(ref CircularBuffer<double> b, int aw)
        {
            int size = aw > b.Size ? b.Size : aw;

            double sumcos = 0, sumsin = 0;
            for (int i = 0; i < size; i++)
            {
                double v = b.Read(i);
                sumcos += Math.Cos(v * Math.PI / 180);
                sumsin += Math.Sin(v * Math.PI / 180);
            }
            return Math.Atan2(sumsin, sumcos);
        }

        public override void PushChartData()
        {
            //Just push current value and not average
            if (_plot && tmpbuf.Size != 0)
            {
                DateTime tm = DateTime.Now;

                LongBuffer.Add(new ChartData { Time = tm, Val = this.Val });
                if (LongBuffer.Count() > ChartDataCollection.MaxSize)
                    LongBuffer.RemoveAt(0);
                tmpbuf.Clear();
            }
        }

    }

    class LatitudeInstrument : PositionInstrument
    {
        public LatitudeInstrument(string dn, string un, int aw)
            : base(dn, un, aw)
        {
        }

        public LatitudeInstrument(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        protected override void FormatValue()
        {
            double deg, min;
            string d, m, c;

            deg = Math.Abs(Math.Truncate(Val));
            min = (Math.Abs(Val) - deg) * 60;

            d = deg.ToString();
            m = min.ToString("0.00");
            if (Val > 0)
                c = "N";
            else
                c = "S";

            FormattedValue = d + "° " + m + "' " + c;
        }
    }

    class LongitudeInstrument : PositionInstrument
    {
        public LongitudeInstrument(string dn, string un, int aw)
            : base(dn, un, aw)
        {
        }

        public LongitudeInstrument(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        protected override void FormatValue()
        {
            double deg, min;
            string d, m, c;

            deg = Math.Abs(Math.Truncate(Val));
            min = (Math.Abs(Val) - deg) * 60;

            d = deg.ToString();
            m = min.ToString("0.00");
            if (Val > 0)
                c = "E";
            else
                c = "W";

            FormattedValue = d + "° " + m + "' " + c;
        }
    }

    class PercentInstrument : LinearInstrument
    {
        public PercentInstrument(string dn, string un, int aw, bool chart)
            : base(dn, un, aw, chart)
        {
        }

        public PercentInstrument(string dn, string un, int aw)
            : base(dn, un, aw)
        {
        }

        protected override void FormatValue()
        {
            _FormattedValue = _average.ToString("#%");
        }
    }

    public class PolarPoint
    {
        public double TWA { get; set; }
        public double SPD { get; set; }
    }

    public class PolarLine
    {
        public double TWS { get; set; }
        public double BeatTWA { get; set; }
        public double RunTWA { get; set; }
        public double BeatSPD { get; set; }
        public double RunSPD { get; set; }

        public List<PolarPoint> Points { get; set; }

        public PolarLine()
        {
            this.TWS = 0;
            this.BeatTWA = 0;
            this.RunTWA = 180;
            this.BeatSPD = 0;
            this.RunSPD = 0;
            this.Points = new List<PolarPoint>();
        }

        public PolarLine(string s)
            : this()
        {
            string[] str = s.Split(',');
            this.TWS = Convert.ToDouble(str[0]);

            double RunVMG = 0, BeatVMG = 0;
            int i = 1;

            while (i < str.Length)
            {
                PolarPoint p = new PolarPoint();
                p.TWA = Convert.ToDouble(str[i]);
                p.SPD = Convert.ToDouble(str[i + 1]);
                Points.Add(p);

                double VMG = p.SPD * Math.Cos(p.TWA * Math.PI / 180);
                if (VMG > BeatVMG)
                {
                    BeatVMG = VMG;
                    BeatTWA = p.TWA;
                    BeatSPD = p.SPD;
                }

                if (VMG < RunVMG)
                {
                    RunVMG = VMG;
                    RunTWA = p.TWA;
                    RunSPD = p.SPD;
                }
                i += 2;
            }
        }

        public double GetTarget(double twa)
        {
            PolarPoint p1 = new PolarPoint();
            PolarPoint p2 = new PolarPoint();
            PolarPoint p3 = new PolarPoint();

            foreach (PolarPoint p in Points)
            {
                if (p.TWA > twa)
                {
                    p2 = p;
                    break;
                }
                else
                    p1 = p;
            }

            p3.SPD = p1.SPD + (twa - p1.TWA) * (p2.SPD - p1.SPD) / (p2.TWA - p1.TWA);

            return p3.SPD;
        }

        public PolarPoint GetTargetVMC(double twd, double brg, double drift, double set)
        {
            PolarPoint pr = new PolarPoint();

            double maxvmc = 0;

            for (double twa = 0; twa <= 180; twa += 1)
            {

                double spd = this.GetTarget(twa);
                double sogx1 = spd * Math.Cos((twd + twa) * Math.PI / 180) + drift * Math.Cos(set * Math.PI / 180);
                double sogy1 = spd * Math.Sin((twd + twa) * Math.PI / 180) + drift * Math.Sin(set * Math.PI / 180);
                double sogx2 = spd * Math.Cos((twd - twa) * Math.PI / 180) + drift * Math.Cos(set * Math.PI / 180);
                double sogy2 = spd * Math.Sin((twd - twa) * Math.PI / 180) + drift * Math.Sin(set * Math.PI / 180);

                double sog1 = Math.Sqrt(sogx1 * sogx1 + sogy1 * sogy1);
                double sog2 = Math.Sqrt(sogx2 * sogx2 + sogy2 * sogy2);

                double cog1 = Math.Atan2(sogy1, sogx1) * 180 / Math.PI;
                double cog2 = Math.Atan2(sogy2, sogx2) * 180 / Math.PI;

                double vmc1 = sog1 * Math.Cos((brg - cog1) * Math.PI / 180);
                double vmc2 = sog2 * Math.Cos((brg - cog2) * Math.PI / 180);

                if (vmc1 > maxvmc)
                {
                    maxvmc = vmc1;
                    pr.SPD = vmc1;
                    pr.TWA = twa;
                }

                if (vmc2 > maxvmc)
                {
                    maxvmc = vmc2;
                    pr.SPD = vmc2;
                    pr.TWA = -twa;
                }
            }

            return pr;
        }
    }

    public class Polar
    {
        public string Name { get; set; }
        public List<PolarLine> Lines { get; set; }
        public Boolean IsLoaded { get; set; }

        public Polar()
        {
            this.Lines = new List<PolarLine>();
            this.IsLoaded = false;
        }

        public void Load(StreamReader f)
        {
            while (f.Peek() >= 0)
            {
                string s = f.ReadLine();
                this.Lines.Add(new PolarLine(s));
            }
            this.IsLoaded = true;
        }

        public double GetTarget(double twa, double tws)
        {
            int i = 0, j = 0;

            foreach (PolarLine pl in Lines)
            {
                if (pl.TWS > tws)
                {
                    j = Lines.IndexOf(pl);
                    break;
                }
                else
                    i = Lines.IndexOf(pl);
            }

            double bs1 = Lines[i].GetTarget(twa);
            double bs2 = Lines[j].GetTarget(twa);
            double tws1 = Lines[i].TWS;
            double tws2 = Lines[j].TWS;

            double bs = bs1 + (bs2 - bs1) * (tws - tws1) / (tws2 - tws1);

            return bs;
        }

        public PolarPoint GetBeatTarget(double tws)
        {
            int i = 0, j = 0;
            PolarPoint p = new PolarPoint();

            foreach (PolarLine pl in Lines)
            {
                if (pl.TWS > tws)
                {
                    j = Lines.IndexOf(pl);
                    break;
                }
                else
                    i = Lines.IndexOf(pl);
            }

            double tws1 = Lines[i].TWS;
            double tws2 = Lines[j].TWS;
            double bs1 = Lines[i].BeatSPD;
            double bs2 = Lines[j].BeatSPD;
            double twa1 = Lines[i].BeatTWA;
            double twa2 = Lines[j].BeatTWA;

            p.SPD = bs1 + (bs2 - bs1) * (tws - tws1) / (tws2 - tws1);
            p.TWA = twa1 + (twa2 - twa1) * (tws - tws1) / (tws2 - tws1);

            return p;
        }

        public PolarPoint GetRunTarget(double tws)
        {
            int i = 0, j = 0;
            PolarPoint p = new PolarPoint();

            foreach (PolarLine pl in Lines)
            {
                if (pl.TWS > tws)
                {
                    j = Lines.IndexOf(pl);
                    break;
                }
                else
                    i = Lines.IndexOf(pl);
            }

            double tws1 = Lines[i].TWS;
            double tws2 = Lines[j].TWS;
            double bs1 = Lines[i].RunSPD;
            double bs2 = Lines[j].RunSPD;
            double twa1 = Lines[i].RunTWA;
            double twa2 = Lines[j].RunTWA;

            p.SPD = bs1 + (bs2 - bs1) * (tws - tws1) / (tws2 - tws1);
            p.TWA = twa1 + (twa2 - twa1) * (tws - tws1) / (tws2 - tws1);

            return p;
        }

        public PolarPoint GetTargetVMC(double tws, double twd, double brg, double drift, double set)
        {
            PolarPoint p1 = new PolarPoint();
            PolarPoint p2 = new PolarPoint();
            PolarPoint p = new PolarPoint();

            int i = 0, j = 0;

            foreach (PolarLine pl in Lines)
            {
                if (pl.TWS > tws)
                {
                    j = Lines.IndexOf(pl);
                    break;
                }
                else
                    i = Lines.IndexOf(pl);
            }

            p1 = Lines[i].GetTargetVMC(twd, brg, drift, set);
            p2 = Lines[j].GetTargetVMC(twd, brg, drift, set);

            double tws1 = Lines[i].TWS;
            double tws2 = Lines[j].TWS;
            double vmc1 = p1.SPD;
            double vmc2 = p2.SPD;
            double twa1 = p1.TWA;
            double twa2 = p2.TWA;

            p.SPD = vmc1 + (vmc2 - vmc1) * (tws - tws1) / (tws2 - tws1);
            p.TWA = twa1 + (twa2 - twa1) * (tws - tws1) / (tws2 - tws1);

            return p;
        }

    }

    public class Route
    {
        public string Name;
        public ObservableCollection<rteEntry> RteEntries;
        public rteEntry ActiveRteEntry;
        public Polyline polyline;

        public Route(string name)
        {
            this.Name = name;
            this.RteEntries = new ObservableCollection<rteEntry>();
            this.polyline = new Polyline();
            SetInactive();
        }

        public Route()
            : this("")
        { }

        public void Add(Waypoint towpt)
        {
            RteEntries.Add(new rteEntry(towpt));
        }

        public void SetInactive()
        {
            double[] ds = { 2, 4 };
            DoubleCollection dashstyle = new DoubleCollection(ds);
            this.polyline.Stroke = Brushes.DeepSkyBlue;
            this.polyline.StrokeThickness = 2;
            this.polyline.StrokeDashArray = dashstyle;
        }

        public void SetActive()
        {
            double[] ds = { 1, 0 };
            DoubleCollection dashstyle = new DoubleCollection(ds);
            this.polyline.Stroke = Brushes.DeepSkyBlue;
            this.polyline.StrokeThickness = 2;
            this.polyline.StrokeDashArray = dashstyle;
        }
    }

    public class rteEntry
    {
        public Waypoint ToWpt { get; set; }
        public Waypoint FromWpt { get; set; }
        public string Distance { get; set; }
        public string AccDist { get; set; }
        public string Bearing { get; set; }
        public string TWA { get; set; }
        public string ETA { get; set; }

        public rteEntry(Waypoint w)
        {
            this.ToWpt = new Waypoint();
            this.ToWpt = w;
            this.FromWpt =new Waypoint();
            this.Bearing = "";
            this.Distance = "";
            this.AccDist = "";
            this.ETA = "";
            this.TWA = "";
        }
    }

    public class BearingLine
    {
        public Line line;
        private RotateTransform rotateT;
        private TranslateTransform TranslateT;


        public BearingLine()
        {
            this.line = new Line();
            double[] ds = { 4, 4 };
            DoubleCollection dashstyle = new DoubleCollection(ds);
            this.line.Stroke = Brushes.Lime;
            this.line.StrokeThickness = 2;
            this.line.StrokeDashArray = dashstyle;
            this.line.X1 = 0;
            this.line.Y1 = 0;
            this.line.X2 = 0;
            this.line.Y2 = 0;


            TransformGroup tg = new TransformGroup();
            this.rotateT = new RotateTransform();
            this.TranslateT = new TranslateTransform();
            tg.Children.Add(this.rotateT);
            tg.Children.Add(this.TranslateT);
            this.line.RenderTransform = tg;
        }

        public void SetLength(double len)
        {
            this.line.Y2 = -len;
        }

        public void SetAngle(double ang)
        {
            this.rotateT.Angle = ang;
        }

        public void SetPosition(double x, double y)
        {
            this.TranslateT.X = x;
            this.TranslateT.Y = y;
        }

    }

    public class WindVane
    {
        public Polygon polygon;
        private RotateTransform rotateT;
        private TranslateTransform TranslateT;

        public WindVane()
        {
            this.polygon = new Polygon();
            this.polygon.Fill = Brushes.White;
            this.polygon.Points.Add(new Point(0, -60));
            this.polygon.Points.Add(new Point(-14, -90));
            this.polygon.Points.Add(new Point(0, -80));
            this.polygon.Points.Add(new Point(14, -90));

            TransformGroup tg = new TransformGroup();
            this.rotateT = new RotateTransform();
            this.TranslateT = new TranslateTransform();
            tg.Children.Add(this.rotateT);
            tg.Children.Add(this.TranslateT);
            this.polygon.RenderTransform = tg;
        }

        public void SetAngle(double ang)
        {
            this.rotateT.Angle = ang;
        }

        public void SetPosition(double x, double y)
        {
            this.TranslateT.X = x;
            this.TranslateT.Y = y;
        }

    }

    public class DriftVane
    {
        public Polygon polygon;
        private RotateTransform rotateT;
        private TranslateTransform TranslateT;

        public DriftVane()
        {
            this.polygon = new Polygon();
            this.polygon.Fill = Brushes.DeepSkyBlue;
            this.polygon.Points.Add(new Point(0, -30));
            this.polygon.Points.Add(new Point(-7, -45));
            this.polygon.Points.Add(new Point(0, -40));
            this.polygon.Points.Add(new Point(7, -45));

            TransformGroup tg = new TransformGroup();
            this.rotateT = new RotateTransform();
            this.TranslateT = new TranslateTransform();
            tg.Children.Add(this.rotateT);
            tg.Children.Add(this.TranslateT);
            this.polygon.RenderTransform = tg;
        }

        public void SetAngle(double ang)
        {
            this.rotateT.Angle = ang;
        }

        public void SetPosition(double x, double y)
        {
            this.TranslateT.X = x;
            this.TranslateT.Y = y;
        }

    }

    public class Track
    {
        public Polyline TrackLine;

        public Track()
        {
            this.TrackLine = new Polyline();
            this.TrackLine.Stroke = Brushes.Violet;
            this.TrackLine.StrokeThickness = 2;
        }

        public void AddPoint(Point p)
        {
            this.TrackLine.Points.Add(p);
        }

    }

    public class Layline
    {
        public Line line;
        private RotateTransform rotateT;
        private TranslateTransform TranslateT;


        public Layline(Brush br)
        {
            this.line = new Line();
            //double[] ds = { 6, 6 };
            //DoubleCollection dashstyle = new DoubleCollection(ds);
            this.line.Stroke = br;
            this.line.StrokeThickness = 3;
            //this.line.StrokeDashArray = dashstyle;
            this.line.X1 = 0;
            this.line.Y1 = 0;
            this.line.X2 = 0;
            this.line.Y2 = 0;

            TransformGroup tg = new TransformGroup();
            this.rotateT = new RotateTransform();
            this.TranslateT = new TranslateTransform();
            tg.Children.Add(this.rotateT);
            tg.Children.Add(this.TranslateT);
            this.line.RenderTransform = tg;
        }

        public void SetLength(double len)
        {
            this.line.Y2 = -len;
        }

        public void SetAngle(double ang)
        {
            this.rotateT.Angle = ang;
        }

        public void SetPosition(double x, double y)
        {
            this.TranslateT.X = x;
            this.TranslateT.Y = y;
        }

    }

    public class WindArrow
    {

        public uvpair components;

        public System.Windows.Shapes.Path path;
        //public Polygon path;
        private RotateTransform rotateT;
        private TranslateTransform TranslateT;
        private ScaleTransform ScaleT;

        public WindArrow()
        {
            components = new uvpair();

            //path = new Polygon();
            path = new System.Windows.Shapes.Path();

            TransformGroup tg = new TransformGroup();
            this.rotateT = new RotateTransform();
            this.TranslateT = new TranslateTransform();
            this.ScaleT = new ScaleTransform();
            tg.Children.Add(this.rotateT);
            tg.Children.Add(this.ScaleT);
            tg.Children.Add(this.TranslateT);
            this.path.RenderTransform = tg;

            LineSegment myLineSegment = new LineSegment();
            myLineSegment.Point = new Point(0, -150);
            LineSegment myLineSegment1 = new LineSegment();
            myLineSegment1.Point = new Point(-60, -150);

            PathFigure myPathFigure = new PathFigure();
            myPathFigure.StartPoint = new Point(0, 0);
            myPathFigure.Segments.Add(myLineSegment);
            myPathFigure.Segments.Add(myLineSegment1);

            PathGeometry myPathGeometry = new PathGeometry();
            myPathGeometry.Figures.Add(myPathFigure);

            //path.Points.Add(new Point(0, 0));
            //path.Points.Add(new Point(-20,-50));
            //path.Points.Add(new Point(-10,-50));
            //path.Points.Add(new Point(-10,-150));
            //path.Points.Add(new Point(10,-150));
            //path.Points.Add(new Point(10,-50));
            //path.Points.Add(new Point(20,-50));            

            path.StrokeThickness = 8;
            path.Data = myPathGeometry;
          
        }

        public void SetAngle(double ang)
        {
            this.rotateT.Angle = ang;
        }

        public void SetPosition(double x, double y)
        {
            this.TranslateT.X = x;
            this.TranslateT.Y = y;
        }
        
        public void SetScale(double sc)
        {
            this.ScaleT.ScaleX = sc;
            this.ScaleT.ScaleY = sc;
        }

        public void SetColor(double it,LinearGradientBrush lgbr)
        {
            Color c = GetColor(it / 30, lgbr);
            SolidColorBrush br = new SolidColorBrush(c);
            path.Stroke = br;
        }

        private Color GetColor(double x, LinearGradientBrush br)
        {

            //Clip the input if before or after the max/min offset values
            double max = br.GradientStops.Max(n => n.Offset);
            if (x > max)
            {
                x = max;
            }
            double min = br.GradientStops.Min(n => n.Offset);
            if (x < min)
            {
                x = min;
            }

            //Find gradient stops that surround the input value
            GradientStop gs0 = br.GradientStops.Where(n => n.Offset <= x).OrderBy(n => n.Offset).Last();
            GradientStop gs1 = br.GradientStops.Where(n => n.Offset >= x).OrderBy(n => n.Offset).First();

            float y = 0f;
            if (gs0.Offset != gs1.Offset)
            {
                y = (float)((x - gs0.Offset) / (gs1.Offset - gs0.Offset));
            }

            //Interpolate color channels
            Color cx = new Color();
            if (br.ColorInterpolationMode == ColorInterpolationMode.ScRgbLinearInterpolation)
            {
                float aVal = (gs1.Color.ScA - gs0.Color.ScA) * y + gs0.Color.ScA;
                float rVal = (gs1.Color.ScR - gs0.Color.ScR) * y + gs0.Color.ScR;
                float gVal = (gs1.Color.ScG - gs0.Color.ScG) * y + gs0.Color.ScG;
                float bVal = (gs1.Color.ScB - gs0.Color.ScB) * y + gs0.Color.ScB;
                cx = Color.FromScRgb(aVal, rVal, gVal, bVal);
            }
            else
            {
                byte aVal = (byte)((gs1.Color.A - gs0.Color.A) * y + gs0.Color.A);
                byte rVal = (byte)((gs1.Color.R - gs0.Color.R) * y + gs0.Color.R);
                byte gVal = (byte)((gs1.Color.G - gs0.Color.G) * y + gs0.Color.G);
                byte bVal = (byte)((gs1.Color.B - gs0.Color.B) * y + gs0.Color.B);
                cx = Color.FromArgb(aVal, rVal, gVal, bVal);
            }
            return cx;
        }
        
    }

    public class WindArrowGrid
    {
        public Collection<WindArrow> windarrows;
        private double scale;

        public WindArrowGrid(ref windgrib wgrib, ref Map map)
        {
            windarrows = new Collection<WindArrow>();

            DateTime dt = wgrib.windbands[0].datetime;

            double dlon = ((map.MaxLon - map.MinLon) + 360) % 360;
            double dlat = ((map.MaxLat - map.MinLat) + 360) % 360;

            double omega_step = (wgrib.MaxLon - wgrib.MinLon) / (wgrib.SizeX - 1);
            double phi_step = (wgrib.MaxLat - wgrib.MinLat) / (wgrib.SizeY - 1);

            double delta;
            if (dlon < dlat) delta = dlon / 10; else delta = dlat / 10;

            if (omega_step < delta) delta = omega_step;
            if (phi_step < delta) delta = phi_step;

            scale = delta * map.Image.PixelHeight / (map.MaxLat - map.MinLat)/600;

            double lat = map.MinLat;

            while (lat < map.MaxLat)
            {
                double lon = map.MinLon;

                while (lon < map.MaxLon)
                {
                    uvpair uv = new uvpair();

                    if (wgrib.GetWind(lat, lon, dt, out uv))
                    {
                        WindArrow wa = new WindArrow();

                        double x, y;
                        map.ConvertToXY(lon, lat, out x, out y);
                        wa.SetPosition(x, y);

                        wa.components.Lat = lat;
                        wa.components.Lon = lon;

                        this.windarrows.Add(wa);
                    }
                        
                        lon += delta;
                }
                lat += delta;
            }

        }

        public void Update(ref windgrib wgrib,DateTime dt)
        {
            LinearGradientBrush cm = (LinearGradientBrush) App.Current.FindResource("ColorMap");

            foreach (WindArrow wa in windarrows)
            {
                uvpair uv = new uvpair();
                wgrib.GetWind(wa.components.Lat, wa.components.Lon, dt, out uv);

                double u = uv.u;
                double v = uv.v;

                double ang = Math.Atan2(u, v) * 180 / Math.PI;
                double it = Math.Sqrt(u * u + v * v) * 3600 / 1852;

                wa.path.ToolTip = it.ToString("#.#");
                wa.SetAngle(ang + 180);

                //double sc = Math.Sqrt(it)*scale/2;
                double sc = it * scale / 10;
                wa.SetScale(sc);
                wa.SetColor(it,cm);                
            }
        }
        
    }

    public class MapIndex
    {
        public List<MapEntry> Maps;

        public MapIndex()
        {
            Maps = new List<MapEntry>();
        }

        public void SetRectangles(ref Map currentmap)
        {
            Maps.Sort();

            foreach(MapEntry me in Maps)
            {
                double x0,y0,x1,y1;
                currentmap.ConvertToXY(me.minLon,me.minLat,out x0,out y0);
                currentmap.ConvertToXY(me.maxLon,me.maxLat,out x1,out y1);
                Canvas.SetLeft(me, x0);
                Canvas.SetTop(me, y0);
                me.Width=x1-x0;
                me.Height=y1-y0;                
            }
        }
    }

    [ValueConversion(typeof(double), typeof(String))]
    public class PositionConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double deg = Math.Truncate((double)value);
            double min = Math.Abs((double)value - deg) * 60;
            return deg.ToString("#") + " " + min.ToString("#.####");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string s = (string)value;
            string[] dm = s.Split(' ');

            if (dm.Count() == 1)
                return double.Parse(dm[0]);
            else
                if (dm.Count() == 2)
                {
                    double deg, min;
                    double.TryParse(dm[0], out deg);
                    double.TryParse(dm[1], out min);
                    min = min / 60 * Math.Sign(deg);
                    return deg + min;
                }
                else
                    return 0;
        }
    }

    //[TypeConverter(typeof(CustomSettingConverter))]
    public class NMEASentence
    {

        private string name;
        public string Name
        {
            set { name = value; }
            get { return name; }
        }

        private int inport;
        public int InPort
        {
            set { inport = value; }            
            get { return inport; }
        }

        private bool outport1;
        public bool OutPort1
        {
            set { outport1 = value; }
            get { return outport1; }
        }

        private bool outport2;
        public bool OutPort2
        {
            set { outport2 = value; }
            get { return outport2; }
        }

        private bool outport3;
        public bool OutPort3
        {
            set { outport3 = value; }
            get { return outport3; }
        }

        private bool outport4;
        public bool OutPort4
        {
            set { outport4 = value; }
            get { return outport4; }
        }

        private string comments;
        public string Comments
        {
            set { comments = value; }
            get { return comments; }
        }
    }

    public class CustomSettingConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(string))
                return true;
            else
                return base.CanConvertFrom(context, sourceType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context,
           CultureInfo culture, object value)
        {
            if (value is string)
            {
                string[] v = ((string)value).Split(new char[] { ',' });
                if (v.Length == 6)
                    return new NMEASentence() { Name = v[0], InPort = int.Parse(v[1]), OutPort1 = bool.Parse(v[2]), OutPort2 = bool.Parse(v[3]), OutPort3 = bool.Parse(v[4]), OutPort4 = bool.Parse(v[5]) };
                else
                    return new NMEASentence();
            }
            return base.ConvertFrom(context, culture, value);
        }
        // Overrides the ConvertTo method of TypeConverter.
        public override object ConvertTo(ITypeDescriptorContext context,
           CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == typeof(string))
            {
                NMEASentence ns = value as NMEASentence;
                return ns.Name + "," + ns.InPort.ToString() + "," + ns.OutPort1.ToString() + "," + ns.OutPort2.ToString() + "," + ns.OutPort3.ToString() + "," + ns.OutPort4.ToString();
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }
    }

    public class ObservableString : INotifyPropertyChanged
    {
        private string _value;        

        public string Value
        {
            get
            { return _value; }

            set
            {
                _value = value;
                NotifyPropertyChanged("Value");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

    }

}
