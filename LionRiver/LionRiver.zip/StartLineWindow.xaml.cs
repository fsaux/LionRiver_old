﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LionRiver
{
    /// <summary>
    /// Interaction logic for StartLineWindow.xaml
    /// </summary>
    public partial class StartLineWindow : Window
    {
        public StartLineWindow()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            if(MainWindow.SetLinePoint2())
                this.button2.Background = Brushes.Lime;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (MainWindow.SetLinePoint1())
                this.button1.Background = Brushes.Lime;
        }
    }
}
