﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.IO.Ports;

namespace LionRiver
{
    /// <summary>
    /// Interaction logic for SetupWindow.xaml
    /// </summary>
    public partial class SetupWindow : Window
    {

        NMEASentence RMB = new NMEASentence();
        NMEASentence RMC = new NMEASentence();
        NMEASentence MWV = new NMEASentence();
        NMEASentence VHW = new NMEASentence();
        NMEASentence HDG = new NMEASentence();
        NMEASentence DBT = new NMEASentence();
        NMEASentence MTW = new NMEASentence();
        NMEASentence PTAK = new NMEASentence();

        List<NMEASentence> NMEASentences = new List<NMEASentence>();

        public ObservableString port1 { get; set; }
        public ObservableString port2 { get; set; }
        public ObservableString port3 { get; set; }
        public ObservableString port4 { get; set; }
        
        public SetupWindow()
        {
            port1 = new ObservableString();
            port2 = new ObservableString();
            port3 = new ObservableString();
            port4 = new ObservableString();

            InitializeComponent();

            this.DataContext = this;            

            if (Properties.Settings.Default.RMB != null) RMB = Properties.Settings.Default.RMB;
            if (Properties.Settings.Default.RMC != null) RMC = Properties.Settings.Default.RMC;
            if (Properties.Settings.Default.DBT != null) DBT = Properties.Settings.Default.DBT;
            if (Properties.Settings.Default.HDG != null) HDG = Properties.Settings.Default.HDG;
            if (Properties.Settings.Default.MTW != null) MTW = Properties.Settings.Default.MTW;
            if (Properties.Settings.Default.VHW != null) VHW = Properties.Settings.Default.VHW;
            if (Properties.Settings.Default.MWV != null) MWV = Properties.Settings.Default.MWV;
            if (Properties.Settings.Default.PTAK != null) PTAK = Properties.Settings.Default.PTAK;

            RMB.Name = "RMB"; RMB.Comments = "GPS Active route";
            RMC.Name = "RMC"; RMC.Comments = "GPS Position";
            DBT.Name = "DBT"; DBT.Comments = "Depth";
            HDG.Name = "HDG"; HDG.Comments = "Magnetic heading";
            MTW.Name = "MTW"; MTW.Comments = "Water temperature";
            VHW.Name = "VHW"; VHW.Comments = "Hull speed through water";
            MWV.Name = "MWV"; MWV.Comments = "Wind speed/angle";
            PTAK.Name = "PTAK"; PTAK.Comments = "Tacktick performance";

            NMEASentences.Add(RMB);
            NMEASentences.Add(RMC); 
            NMEASentences.Add(DBT);
            NMEASentences.Add(HDG);
            NMEASentences.Add(MTW);
            NMEASentences.Add(VHW);
            NMEASentences.Add(MWV);
            NMEASentences.Add(PTAK);

            foreach (string s in SerialPort.GetPortNames())
            {
                Combobox1.Items.Add(s);
                Combobox2.Items.Add(s);
                Combobox3.Items.Add(s);
                Combobox4.Items.Add(s);
            }

            Combobox1.Items.Add("None");
            Combobox2.Items.Add("None");
            Combobox3.Items.Add("None");
            Combobox4.Items.Add("None");

            if (Properties.Settings.Default.Port1 != "") Combobox1.SelectedValue = Properties.Settings.Default.Port1; else Combobox1.SelectedIndex = 0;
            if (Properties.Settings.Default.Port2 != "") Combobox2.SelectedValue = Properties.Settings.Default.Port2; else Combobox2.SelectedIndex = 0;
            if (Properties.Settings.Default.Port3 != "") Combobox3.SelectedValue = Properties.Settings.Default.Port3; else Combobox3.SelectedIndex = 0;
            if (Properties.Settings.Default.Port4 != "") Combobox4.SelectedValue = Properties.Settings.Default.Port4; else Combobox4.SelectedIndex = 0;

            port1.Value=Combobox1.SelectedValue.ToString();
            port2.Value=Combobox2.SelectedValue.ToString();
            port3.Value=Combobox3.SelectedValue.ToString();
            port4.Value=Combobox4.SelectedValue.ToString();

            dataGrid1.DataContext = NMEASentences;

            textBox1.Text = Properties.Settings.Default.MagVar.ToString();

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Port1 = (string)Combobox1.SelectedValue;
            Properties.Settings.Default.Port2 = (string)Combobox2.SelectedValue;
            Properties.Settings.Default.Port3 = (string)Combobox3.SelectedValue;
            Properties.Settings.Default.Port4 = (string)Combobox4.SelectedValue;

            Properties.Settings.Default.RMB = RMB;
            Properties.Settings.Default.RMC = RMC;
            Properties.Settings.Default.DBT = DBT;
            Properties.Settings.Default.HDG = HDG;
            Properties.Settings.Default.MTW = MTW;
            Properties.Settings.Default.VHW = VHW;
            Properties.Settings.Default.MWV = MWV;
            Properties.Settings.Default.PTAK = PTAK;

            Properties.Settings.Default.MagVar = Convert.ToDouble(textBox1.Text);

            Properties.Settings.Default.Save();
            this.Close();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();

            dlg.SelectedPath = Properties.Settings.Default.MapsDirectory;

            // Show browse file dialog box

            DialogResult result = dlg.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                // Save document
                string foldername = dlg.SelectedPath;
                Properties.Settings.Default.MapsDirectory = foldername;
            }
        }

        private void Combobox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            port1.Value = Combobox1.SelectedItem.ToString();
        }

        private void Combobox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            port2.Value = Combobox2.SelectedItem.ToString();
        }

        private void Combobox3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            port3.Value = Combobox3.SelectedItem.ToString();
        }

        private void Combobox4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            port4.Value = Combobox4.SelectedItem.ToString();
        }

    }
}
