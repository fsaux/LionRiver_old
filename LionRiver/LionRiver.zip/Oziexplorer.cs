﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace LionRiver
{
    public delegate void MMpositionCallback(double Lat, double Lon, double Spd, double Hdg, double Mag, double Alt);

    static class Oziexplorer
    {
        [DllImport("OziAPI.dll")] public static extern int oziFindOzi();
        [DllImport("OziAPI.dll")] public static extern int oziCloseApi();
        [DllImport("OziAPI.dll")] public static extern int oziSendMMpositionON(MMpositionCallback cb);
        [DllImport("OziAPI.dll")] public static extern int oziSendMMpositionOFF();
        [DllImport("OziAPI.dll")] public static extern int oziGps2NavWp(ref string sname,ref string descr,ref double dist,ref double brg);

    }
}
