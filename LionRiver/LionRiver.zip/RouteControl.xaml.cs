﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LionRiver
{
    /// <summary>
    /// Interaction logic for RouteControl.xaml
    /// </summary>
    public partial class RouteControl : UserControl
    {
        public RouteControl()
        {
            InitializeComponent();
        }

        public event RouteCtrlEventHandler RouteCtrlHd;

        protected virtual void OnRouteCtrl(RouteCtrlEventArgs e)
        {
            RouteCtrlEventHandler handler = RouteCtrlHd;
            if (handler != null)
            {
                // Invokes the delegates.
                handler(this, e);
            }
        }

        private void ActivateRoute_Click(object sender, RoutedEventArgs e)
        {
            if (RouteListComboBox.SelectedItem != null)
            {
                RouteCtrlEventArgs ea = new RouteCtrlEventArgs(RouteListComboBox.SelectedItem.ToString(), RouteCtrlCmd.ActivateRoute);
                OnRouteCtrl(ea);
            }
        }

        private void RouteListComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RouteListComboBox.SelectedItem != null)
            {
                RouteCtrlEventArgs ea = new RouteCtrlEventArgs(RouteListComboBox.SelectedItem.ToString(), RouteCtrlCmd.SelectionChanged);
                OnRouteCtrl(ea);
            }
        }

        private void NewRoute_Click(object sender, RoutedEventArgs e)
        {
            RouteCtrlEventArgs ea = new RouteCtrlEventArgs("", RouteCtrlCmd.NewRoute);
            OnRouteCtrl(ea);
        }
    }


    public class RouteCtrlEventArgs : EventArgs
    {
        private string rtenam;
        private RouteCtrlCmd command;

        public RouteCtrlEventArgs(string rtn, RouteCtrlCmd cmd)
        {
            this.rtenam = rtn;
            this.command = cmd;
        }

        public string RouteName
        {
            get { return rtenam; }
        }

        public RouteCtrlCmd Command
        {
            get { return command; }
        }
    }

    public delegate void RouteCtrlEventHandler(object sender, RouteCtrlEventArgs e);

    public enum RouteCtrlCmd
    {
        ActivateRoute,
        SelectionChanged,
        NewRoute,
        DeleteRoute,
        AddWaypointStart,
        AddWaypointStop
    }



}
