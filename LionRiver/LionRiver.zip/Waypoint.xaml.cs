﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;


namespace LionRiver
{
    /// <summary>
    /// Interaction logic for Waypoint.xaml
    /// </summary>
    /// 


    public partial class Waypoint : UserControl, INotifyPropertyChanged
    {
        private double _lat;
        public double Lat
        {
            get { return _lat; }
            set
            {
                _lat = value;
                WaypointEventArgs ea = new WaypointEventArgs(WaypointCmd.Reposition);
                OnWaypoint1(this, ea);
            }
        }
        
        private double _lon;
        public double Lon
        {
            get { return _lon; }
            set
            {
                _lon = value;
                WaypointEventArgs ea = new WaypointEventArgs(WaypointCmd.Reposition);
                OnWaypoint1(this, ea);
            }
        }

        private string _wptname;
        public string WptName
        {
            get { return _wptname; }
            set
            {
                _wptname = value;
                OnPropertyChanged("WptName");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        public Waypoint(string name, double lat, double lon)
        {
            InitializeComponent();

            DataContext = this;

            WptName = name;
            Lat = lat;
            Lon = lon;

            //this.textblock.Text = name;

            SetInactive();
        }

        public Waypoint() :
            this("", 0, 0)
        { }

        public void SetPosition(double x, double y)
        {
            Canvas.SetLeft(this, x);
            Canvas.SetTop(this, y);
            OnPropertyChanged("Lat");
            OnPropertyChanged("Lon");
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            this.txform.X = -this.panel.ActualWidth / 2;
            this.txform.Y = -this.panel.ActualHeight / 2;
        }

        public event WaypointEventHandler WaypointHd;

        protected virtual void OnWaypoint(object sender, WaypointEventArgs e)
        {
            MenuItem mi = sender as MenuItem;
            ContextMenu cm = mi.Parent as ContextMenu;
            Grid ui = cm.PlacementTarget as Grid;
            Waypoint wp = ui.Parent as Waypoint;

            WaypointEventHandler handler = WaypointHd;
            if (handler != null)
            {
                // Invokes the delegates.
                handler(wp, e);
            }
        }

        public virtual void OnWaypoint1(object sender, WaypointEventArgs e)
        {

            WaypointEventHandler handler = WaypointHd;
            if (handler != null)
            {
                // Invokes the delegates.
                handler(sender, e);
            }
        }

        private void ActivateWpt_Click(object sender, RoutedEventArgs e)
        {
            WaypointEventArgs ea = new WaypointEventArgs(WaypointCmd.Activate);
            OnWaypoint(sender, ea);
        }

        private void DeleteWpt_Click(object sender, RoutedEventArgs e)
        {
            WaypointEventArgs ea = new WaypointEventArgs(WaypointCmd.Delete);
            OnWaypoint(sender,ea);
        }

        private void Move_Click_1(object sender, RoutedEventArgs e)
        {
            WaypointEventArgs ea = new WaypointEventArgs(WaypointCmd.Move);
            OnWaypoint(sender,ea);

        }

        private void AddToRoute_Click(object sender, RoutedEventArgs e)
        {
            WaypointEventArgs ea = new WaypointEventArgs(WaypointCmd.AddtoRoute);
            OnWaypoint(sender,ea);
        }

        public void SetActive()
        {
            shapeActive.Visibility = Visibility.Visible;
            shapeInactive.Visibility = Visibility.Hidden;
        }

        public void SetInactive()
        {
            shapeActive.Visibility = Visibility.Hidden;
            shapeInactive.Visibility = Visibility.Visible;
        }

        private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            this.txform.X = -this.panel.ActualWidth / 2;
            this.txform.Y = -this.panel.ActualHeight / 2;
        }

    }

    public class WaypointEventArgs : EventArgs
    {
        private WaypointCmd command;

        public WaypointEventArgs( WaypointCmd cmd)
        {
            this.command = cmd;
        }

        public WaypointCmd Command
        {
            get { return command; }
        }
    }

    public delegate void WaypointEventHandler(object sender, WaypointEventArgs e);

    public enum WaypointCmd
    {
        Activate,
        Delete,
        AddtoRoute,
        Move,
        Reposition
    }
}
