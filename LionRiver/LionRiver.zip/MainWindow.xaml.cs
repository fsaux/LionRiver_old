﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Shapes;
using System.Media;
using System.Xml;

using OSGeo.GDAL;
using OSGeo.OGR;
using OSGeo.OSR;
using OSGeo;

namespace LionRiver
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetEnvironmentVariable(string lpName, string lpValue);

        #region Comm
        static MMpositionCallback GetPosCallBack = new MMpositionCallback(GetPosition);

        static bool OziRunning = false;
        static bool DataReceivedFromOzi = false;
        static bool DataReceivedOnNMEA1 = false;
        static bool DataReceivedOnNMEA2 = false;
        static bool DataReceivedOnNMEA3 = false;
        static bool DataReceivedOnNMEA4 = false;

        #endregion

        #region Instruments
        static AngularInstrumentAbs COG = new AngularInstrumentAbs("COG", "°T", 1, true);
        static LinearInstrument SOG = new LinearInstrument("SOG", "Kn", 1, true);
        static PositionInstrument LAT = new LatitudeInstrument("Lat", "", 1,true);
        static PositionInstrument LON = new LongitudeInstrument("Lon", "", 1,true);
        static AngularInstrumentRel MVAR = new AngularInstrumentRel("MVar", "°", 1);
        static LinearInstrument SPD = new LinearInstrument("SPD", "Kn", 4, true);
        static LinearInstrument TEMP = new LinearInstrument("Temp", "°C", 4, true);
        static LinearInstrument DPT = new LinearInstrument("Depth", "m", 4, true);
        static LinearInstrument AWS = new LinearInstrument("AWS", "Kn", 1, true);
        static AngularInstrumentRel AWA = new AngularInstrumentRel("AWA", "°", 4, true);
        static LinearInstrument TWS = new LinearInstrument("TWS", "Kn", 4, true);
        static AngularInstrumentRel TWA = new AngularInstrumentRel("TWA", "°", 4, true);
        static AngularInstrumentAbs TWD = new AngularInstrumentAbs("TWD", "°", 15, true);
        static AngularInstrumentAbs HDT = new AngularInstrumentAbs("HDG", "°T", 4);
        static AngularInstrumentAbs BRG = new AngularInstrumentAbs("BRG", "°T", 1);
        static LinearInstrument DST = new LinearInstrument("DST", "Nm", 1);
        static LinearInstrument XTE = new LinearInstrument("XTE", "Nm", 1);
        static LinearInstrument VMG = new LinearInstrument("WMG", "Kn", 1, true);

        // Destination Waypoint
        static Instrument WPT = new Instrument("To:", "", 1);
        static PositionInstrument WLAT = new LatitudeInstrument("Lat", "", 1);
        static PositionInstrument WLON = new LongitudeInstrument("Lon", "", 1);

        // Last Waypoint
        static Instrument LWPT = new Instrument("", "", 1);
        static PositionInstrument LWLAT = new LatitudeInstrument("Lat", "", 1);
        static PositionInstrument LWLON = new LongitudeInstrument("Lon", "", 1);
        static AngularInstrumentAbs LEGBRG = new AngularInstrumentAbs("BRG", "", 1);
        static LinearInstrument VMGWPT = new LinearInstrument("WMGwpt", "Kn", 1, true);

        // Drift
        static AngularInstrumentAbs SET = new AngularInstrumentAbs("Set", "°T", 30, true);
        static LinearInstrument DRIFT = new LinearInstrument("Drift", "Kn", 30, true);

        // Performance
        static LinearInstrument TGTSPD = new LinearInstrument("Tgt SPD", "Kn", 15);
        static AngularInstrumentRel TGTTWA = new AngularInstrumentRel("Tgt TWA", "°T", 15);
        static PercentInstrument PERF = new PercentInstrument("Perf", "", 15, true);
        static LinearInstrument TGTVMC = new LinearInstrument("Tgt VMC", "Kn", 1, true);
        static AngularInstrumentAbs TGTCTS = new AngularInstrumentAbs("Tgt CTS", "°T", 1, true);

        // Satrting Line
        static LinearInstrument LINEDST = new LinearInstrument("Dst to line", "m", 1);

        // Laylines
        static AngularInstrumentAbs TGTCOGs = new AngularInstrumentAbs("Tgt COG Stbd", "°T", 15);
        static AngularInstrumentAbs TGTCOGp = new AngularInstrumentAbs("Tgt COG Port", "°T", 15);
        static LinearInstrument TGTSOGs = new LinearInstrument("Tgt SOG Stbd", "Kn", 15);
        static LinearInstrument TGTSOGp = new LinearInstrument("Tgt SOG Port", "Kn", 15);

        //Instruments that need to be displayed, averaged and stored over long period
        static Collection<Instrument> InstrumentCollection = new Collection<Instrument> {LAT,LON,COG,SOG,SPD,TEMP,DPT,AWS,AWA,TWS,TWA,TWD,
            VMG,VMGWPT,SET,DRIFT,PERF,TGTVMC,TGTCTS}; 
        #endregion
        
        #region Timers
        DispatcherTimer OziTimer = new DispatcherTimer();
        DispatcherTimer NMEATimer = new DispatcherTimer();
        DispatcherTimer ShortNavTimer = new DispatcherTimer();
        DispatcherTimer MediumNavTimer = new DispatcherTimer();
        DispatcherTimer LongNavTimer = new DispatcherTimer();
        DispatcherTimer XLNavTimer = new DispatcherTimer(); 
        #endregion

        #region LogFile
        StreamWriter LogFile;
        bool Logging = false;
        bool CommentLogged = false;
        string Comment; 
        #endregion

        #region Polar
        static Polar NavPolar; 
        #endregion

        #region Start Line
        // Starting Line position
        static double p1_lat, p1_lon, p2_lat, p2_lon;
        static double linebrg;
        static bool p1_set = false;
        static bool p2_set = false; 
        #endregion
        
        #region Map
        // Map pan & zoom info
        public enum MouseHandlingMode
        {
            None,
            Panning,
            Zooming,
            MovingWaypoint,
            MovingWptandPanning
        }
        private MouseHandlingMode mouseHandlingMode = MouseHandlingMode.None;
        private Point start;
        private Point origin;
        private MouseButton mouseButtonDown;

        static Map map;
        static bool maploaded;
        static MapIndex mapindex;

        #endregion

        #region Waypoints
        WaypointControl waypointControl = new WaypointControl();
        static ObservableCollection<Waypoint> WaypointList = new ObservableCollection<Waypoint>();
        int wptnumber = 0;
        Waypoint MovingWpt;
        #endregion

        #region Routes
        RouteControl routeControl = new RouteControl();
        List<Route> RouteList = new List<Route>();
        static Route ActiveRoute, SelectedRoute;
        int rtenumber = 0; 
        #endregion

        #region Shapes

        BearingLine bearingLine = new BearingLine();
        Track track = new Track();
        WindVane windvane = new WindVane();
        DriftVane driftvane = new DriftVane();
        Layline Layline_p = new Layline(Brushes.Red);
        Layline Layline_s = new Layline(Brushes.Green);

        #endregion

        #region Grib
        GribControl gribControl = new GribControl();
        windgrib wgrib;
        WindArrowGrid waGrid;
        #endregion
        
        public MainWindow()
        {
            InitializeComponent();

            #region Timers
            OziTimer.Tick += new EventHandler(OziTimer_Tick);
            OziTimer.Interval = new TimeSpan(0, 0, 5);

            NMEATimer.Tick += new EventHandler(NMEATimer_Tick);
            NMEATimer.Interval = new TimeSpan(0, 0, 3);

            ShortNavTimer.Tick += new EventHandler(ShortNavTimer_Tick);
            ShortNavTimer.Interval = new TimeSpan(0, 0, 1);

            MediumNavTimer.Tick += new EventHandler(MediumNavTimer_Tick);
            MediumNavTimer.Interval = new TimeSpan(0, 0, 4);

            LongNavTimer.Tick += new EventHandler(LongNavTimer_Tick);
            LongNavTimer.Interval = new TimeSpan(0, 0, 15);

            XLNavTimer.Tick += new EventHandler(XLNavTimer_Tick);
            XLNavTimer.Interval = new TimeSpan(0, 15,0);

            NMEATimer.Start();
            ShortNavTimer.Start();
            MediumNavTimer.Start();
            LongNavTimer.Start();
            XLNavTimer.Start();
            #endregion

            #region Ports and Threads
            OziTimer.Start();
            if (Oziexplorer.oziFindOzi() == 0)
            {
                Oziexplorer.oziSendMMpositionON(GetPosCallBack);
                OziRunning = true;
            }

            SerialPort1 = new SerialPort();
            InitializeSerialPort1();

            SerialPort2 = new SerialPort();
            InitializeSerialPort2();

            SerialPort3 = new SerialPort();
            InitializeSerialPort3();

            SerialPort4 = new SerialPort();
            InitializeSerialPort4();

            readThread1 = new Thread(ReadSerial1);
            terminateThread1 = false;
            readThread1.Start();

            readThread2 = new Thread(ReadSerial2);
            terminateThread2 = false;
            readThread2.Start();

            readThread3 = new Thread(ReadSerial3);
            terminateThread3 = false;
            readThread3.Start();

            readThread4 = new Thread(ReadSerial4);
            terminateThread4 = false;
            readThread4.Start();


            if (Properties.Settings.Default.PTAK == null)
            {
                NMEASentence dummy = new NMEASentence();
                Properties.Settings.Default.PTAK = dummy;
                Properties.Settings.Default.Save();
            }

            SendPTAKheaders();

            #endregion

            #region Polars
            NavPolar = new Polar(); 
            #endregion

            #region Instrument display context binding
            this.userControl11.DataContext = WPT;
            this.userControl12.DataContext = COG;
            this.userControl13.DataContext = BRG;
            this.userControl14.DataContext = SOG;
            this.userControl15.DataContext = DST;
            this.userControl16.DataContext = XTE;

            this.userControl17.DataContext = COG;
            this.userControl18.DataContext = HDT;
            this.userControl19.DataContext = SOG;
            this.userControl20.DataContext = SPD;
            this.userControl21.DataContext = DRIFT;
            this.userControl22.DataContext = SET;

            this.userControl23.DataContext = TWA;
            this.userControl24.DataContext = TWS;
            this.userControl25.DataContext = TWD;
            this.userControl26.DataContext = TGTSPD;
            this.userControl27.DataContext = TGTTWA;
            this.userControl28.DataContext = PERF;

            this.userControl29.DataContext = TWD;
            this.userControl30.DataContext = TGTCOGs;
            this.userControl31.DataContext = TGTCOGp;
            this.userControl32.DataContext = TGTSOGs;
            this.userControl33.DataContext = TGTSOGp;

            this.TextBlock1.DataContext = LAT;
            this.TextBlock2.DataContext = LON;

            this.LineSeries1.DataContext = TWD.LongBuffer;
            this.LinearAxis1.DataContext = TWD.DisplayName;

            this.LineSeries2.DataContext = TWS.LongBuffer;
            this.LinearAxis2.DataContext = TWS.DisplayName; 
            #endregion

            #region Mapping
            string GDAL_HOME = @";C:\GDAL\bin";
            string path = Environment.GetEnvironmentVariable("PATH");
            path += ";" + GDAL_HOME;
            SetEnvironmentVariable("PATH", path);

            Gdal.AllRegister();
            Ogr.RegisterAll();

            maploaded = false;
            if (Properties.Settings.Default.LastMap != "")
            {
                map = new Map(Properties.Settings.Default.LastMap);
                MapImg.Source = map.Image;
                OpacitySlider.Value = 6;

                maploaded = true;
            }

            mapindex = new MapIndex();
            LoadMapIndex();

            TransformGroup group = new TransformGroup();
            ScaleTransform scalexform = new ScaleTransform();
            scalexform.ScaleX = Properties.Settings.Default.MapScale;
            scalexform.ScaleY = Properties.Settings.Default.MapScale;
            group.Children.Add(scalexform);
            TranslateTransform transxform = new TranslateTransform();
            transxform.X = Properties.Settings.Default.MapX;
            transxform.Y = Properties.Settings.Default.MapY;
            group.Children.Add(transxform);
            content.RenderTransform = group;

            #endregion

            #region Shapes
            if (maploaded)
            {
                bearingLine.SetLength(Math.Sqrt(Math.Pow(map.Image.Width, 2) + Math.Pow(map.Image.Height, 2)));
                content.Children.Add(bearingLine.line);
                content.Children.Add(track.TrackLine);
                content.Children.Add(windvane.polygon);
                content.Children.Add(driftvane.polygon);
                content.Children.Add(Layline_s.line);
                content.Children.Add(Layline_p.line);

            }
            #endregion

            #region Waypoints
            waypointControl.AddButton.Click += new RoutedEventHandler(Waypoint_AddButton_Click);
            waypointControl.DataContext = WaypointList;
            #endregion

            #region Routes
            routeControl.RouteCtrlHd += new RouteCtrlEventHandler(RouteCtrlCommandReceived);
            routeControl.LoadButton.Click += new RoutedEventHandler(RouteLoadButton_Click); 
            #endregion

            #region Grib
            gribControl.GribSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(GribSlider_ValueChanged);
            gribControl.LoadButton.Click += new RoutedEventHandler(GribLoadButton_Click); 
            gribControl.NowButton.Click+=new RoutedEventHandler(GribNowButton_Click);
            gribControl.GribWindCheck.Click += new RoutedEventHandler(GribWindCheck_Click);
            #endregion

            //RenderOptions.ProcessRenderMode = System.Windows.Interop.RenderMode.SoftwareOnly;

         }

        private void OziTimer_Tick(object sender, EventArgs e)
        {




        }

        private void NMEATimer_Tick(object sender, EventArgs e)
        {
            if (DataReceivedOnNMEA1)
            {
                DataReceivedOnNMEA1 = false;
                borderPort1.Background = Brushes.Violet;
            }
            else
            {
                borderPort1.Background = Brushes.LightGray;
            }

            if (DataReceivedOnNMEA2)
            {
                DataReceivedOnNMEA2 = false;
                borderPort2.Background = Brushes.Orange;
            }
            else
            {
                borderPort2.Background = Brushes.LightGray;
            }

            if (DataReceivedOnNMEA3)
            {
                DataReceivedOnNMEA3 = false;
                borderPort3.Background = Brushes.Cyan;
            }
            else
            {
                borderPort3.Background = Brushes.LightGray;
            }

            if (DataReceivedOnNMEA4)
            {
                DataReceivedOnNMEA4 = false;
                borderPort4.Background = Brushes.Yellow;
            }
            else
            {
                borderPort4.Background = Brushes.LightGray;
            }

        }

        private void ShortNavTimer_Tick(object sender, EventArgs e)
        {
            GetNavData();
            CalcNav();
            SendNMEA();
            if(Logging)
                WriteToLog();
            UpdateShapes();
        }

        private void MediumNavTimer_Tick(object sender, EventArgs e)
        {
            SendPerformanceNMEA();
        }

        private void LongNavTimer_Tick(object sender, EventArgs e)
        {
            foreach (Instrument i in InstrumentCollection)
                i.PushChartData();
            ChangeTimeAxis();
            CalcLongNav();
            CalcRouteData();
            routeControl.DataGrid1.Items.Refresh();
            
            if (maploaded && LAT.IsValid())
            {
                double x, y;
                map.ConvertToXY(LON.Val, LAT.Val, out x, out y);
                track.AddPoint(new Point(x, y));
            }
        }

        private void XLNavTimer_Tick(object sender, EventArgs e)
        {
            SetGribTimeNow();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Oziexplorer.oziCloseApi();
            CloseSerialPort1();
            CloseSerialPort2();
            CloseSerialPort3();
            CloseSerialPort4();

            Properties.Settings.Default.Save();

        }

        private void MenuItem_Setup_Click(object sender, RoutedEventArgs e)
        {
            SetupWindow SetupWindow1 = new SetupWindow();

            //SetupWindow1.DataContext = SetupWindow1;
            SetupWindow1.Show();

            SerialPort1.Close();
            InitializeSerialPort1();
            DataReceivedOnNMEA1 = false;

            SerialPort2.Close();
            InitializeSerialPort2();
            DataReceivedOnNMEA2 = false;

            SerialPort3.Close();
            InitializeSerialPort3();
            DataReceivedOnNMEA3 = false;

            SerialPort4.Close();
            InitializeSerialPort4();
            DataReceivedOnNMEA4 = false;

            SendPTAKheaders();
        }

        private void MenuItem_Start_Click(object sender, RoutedEventArgs e)
        {
            StartLineWindow StartWindow = new StartLineWindow();

            StartWindow.Show();
        }

        private void MenuItem_LogToFile_Click(object sender, RoutedEventArgs e)
        {
            if (!Logging)
            {
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() +
                                DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + ".log";   // Default file name
                dlg.InitialDirectory = Properties.Settings.Default.LogDirectory;

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                if (result == true)
                {
                    // Save document
                    string filename = dlg.FileName;
                    Properties.Settings.Default.LogDirectory = System.IO.Path.GetDirectoryName(filename);
                    LogFile = new StreamWriter(filename);
                    LogFile.WriteLine("Time,COG,HDG,SOG,SPD,AWA,AWS,Comments");
                    Logging = true;
                }
            }
            else
            {
                LogFile.Close();
                Logging = false;
            }
        }

        private void MenuItem_Polar_Click(object sender, RoutedEventArgs e)
        {

            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            dlg.Filter = "Polar files|*.pol";
            dlg.InitialDirectory = Properties.Settings.Default.PolarDirectory;
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Read Polar
                string filename = dlg.FileName;
                Properties.Settings.Default.PolarDirectory = System.IO.Path.GetDirectoryName(filename);

                StreamReader sr = new StreamReader(filename);
                NavPolar.Load(sr);
                sr.Close();
                SendPTAKheaders();
            }

        }

        private void MenuItem_InsertComment_Click(object sender, RoutedEventArgs e)
        {
            LogCommentDlg dlg = new LogCommentDlg();

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                CommentLogged = true;
                Comment = dlg.textBox1.Text;
            }
        }

        private void MenuUtem_TWD_Click(object sender, RoutedEventArgs e)
        {

            this.LineSeries1.DataContext = TWD.LongBuffer;
            this.LinearAxis1.DataContext = TWD.DisplayName;

            this.LineSeries2.DataContext = TWS.LongBuffer;
            this.LinearAxis2.DataContext = TWS.DisplayName;
        }

        private void MenuUtem_COG_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = COG.LongBuffer;
            this.LinearAxis1.DataContext = COG.DisplayName;

            this.LineSeries2.DataContext = HDT.LongBuffer;
            this.LinearAxis2.DataContext = HDT.DisplayName;
        }

        private void MenuUtem_SOG_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = SOG.LongBuffer;
            this.LinearAxis1.DataContext = SOG.DisplayName;

            this.LineSeries2.DataContext = SPD.LongBuffer;
            this.LinearAxis2.DataContext = SPD.DisplayName;
        }

        private void MenuUtem_DRIFT_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = DRIFT.LongBuffer;
            this.LinearAxis1.DataContext = DRIFT.DisplayName;

            this.LineSeries2.DataContext = SET.LongBuffer;
            this.LinearAxis2.DataContext = SET.DisplayName;
        }

        private void MenuUtem_VMG_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = VMG.LongBuffer;
            this.LinearAxis1.DataContext = VMG.DisplayName;

            this.LineSeries2.DataContext = VMGWPT.LongBuffer;
            this.LinearAxis2.DataContext = VMGWPT.DisplayName;
        }

        private void MenuUtem_TEMP_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = DPT.LongBuffer;
            this.LinearAxis1.DataContext = DPT.DisplayName;

            this.LineSeries2.DataContext = TEMP.LongBuffer;
            this.LinearAxis2.DataContext = TEMP.DisplayName;
        }

        private void MenuUtem_PERF_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = PERF.LongBuffer;
            this.LinearAxis1.DataContext = PERF.DisplayName;

            this.LineSeries2.DataContext = SPD.LongBuffer;
            this.LinearAxis2.DataContext = SPD.DisplayName;
        }

        private void MenuUtem_VMC_Click(object sender, RoutedEventArgs e)
        {
            this.LineSeries1.DataContext = TGTVMC.LongBuffer;
            this.LinearAxis1.DataContext = TGTVMC.DisplayName;

            this.LineSeries2.DataContext = TGTCTS.LongBuffer;
            this.LinearAxis2.DataContext = TGTCTS.DisplayName;
        }

        private void MenuItem_LoadMap_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            dlg.Filter = "BSB files|*.kap";
            dlg.InitialDirectory = Properties.Settings.Default.MapDirectory;
            Nullable<bool> result = dlg.ShowDialog();
            

            if (result == true)
            {
                string filename = dlg.FileName;
                Properties.Settings.Default.MapDirectory = System.IO.Path.GetDirectoryName(filename);               
                LoadMap(filename);
            }
        }

        private void LoadMap(string filename)
        {
            try
            {
                map = new Map(filename);
            }
            catch (Exception)
            {
                return;
            }

            MapImg.Source = map.Image;

            maploaded = true;

            ZoomAll();

            bearingLine.SetLength(Math.Sqrt(Math.Pow(map.Image.Width, 2) + Math.Pow(map.Image.Height, 2)));

            // Reposition loaded shapes
            RepositionWaypoints();
            RepositionRoutes();
            RepositionTrack();
            RepositionWindGrib();

            Properties.Settings.Default.LastMap = filename;

        }

        private void RouteLoadButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            dlg.Filter = "gpx files|*.gpx";
            dlg.InitialDirectory = Properties.Settings.Default.WaypointDirectory;
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = dlg.FileName;
                Properties.Settings.Default.WaypointDirectory = System.IO.Path.GetDirectoryName(filename);

                DataSource inputDS;
                Layer layer;
                Feature f;

                inputDS =  Ogr.Open(filename,0);


                foreach (Waypoint wc in WaypointList)
                    content.Children.Remove(wc);
                WaypointList.Clear();

                foreach (Route r in RouteList)
                    content.Children.Remove(r.polyline);
                RouteList.Clear();
                ActiveRoute = null;
                SelectedRoute = null;
                routeControl.RouteListComboBox.Items.Clear();

                layer = inputDS.GetLayerByName("waypoints");

                while ((f = layer.GetNextFeature()) != null)
                {
                    OSGeo.OGR.Geometry g = f.GetGeometryRef();
                    Waypoint wp = new Waypoint(f.GetFieldAsString("name"), g.GetY(0), g.GetX(0));
                    wp.WaypointHd += new WaypointEventHandler(WaypointCommandReceived);
                    WaypointList.Add(wp);
                }

                // Add Waypoint shapes to Canvas (content)
                AddWaypointsToCanvas();

                RouteList.Clear();

                layer = inputDS.GetLayerByName("routes");
                while ((f = layer.GetNextFeature()) != null)
                {
                    string name=f.GetFieldAsString("name");
                    RouteList.Add(new Route(name));
                    routeControl.RouteListComboBox.Items.Add(name);
                }

                layer = inputDS.GetLayerByName("route_points");
                while ((f = layer.GetNextFeature()) != null)
                {
                    int route_fid = f.GetFieldAsInteger("route_fid");
                    string name = f.GetFieldAsString("name");
                    Waypoint wpt = WaypointList.First(wx => wx.WptName == name);
                    RouteList[route_fid].Add(wpt);
                }

                // Add Routes to Canvas

                AddRoutesToCanvas();

                WPT.Invalidate();
                LWPT.Invalidate();
                LEGBRG.Invalidate();

                routeControl.DataContext = RouteList[0].RteEntries;
                routeControl.RouteListComboBox.SelectedIndex = 0;
                
            }
        }

        private void MenuItem_SaveWaypoint_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

            dlg.Filter = "gpx files|*.gpx";
            dlg.InitialDirectory = Properties.Settings.Default.MapDirectory;
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = dlg.FileName;
                Properties.Settings.Default.MapDirectory = System.IO.Path.GetDirectoryName(filename);


                if (File.Exists(filename))
                    File.Delete(filename);
                
                SpatialReference wgs84;
                string wkt;
                Osr.GetWellKnownGeogCSAsWKT("WGS84", out wkt);
                wgs84 = new SpatialReference(wkt);

                OSGeo.OGR.Driver drv = Ogr.GetDriverByName("GPX");
                DataSource ds = drv.CreateDataSource(filename, new string[] { });
                
                //Write Waypoints
                
                Layer layer1 = ds.CreateLayer("waypoints", wgs84, wkbGeometryType.wkbPoint, new string[] { });
                Feature f1 = new Feature(layer1.GetLayerDefn());
                OSGeo.OGR.Geometry g1 = new OSGeo.OGR.Geometry(wkbGeometryType.wkbPoint);

                foreach (Waypoint w in WaypointList)
                {
                    f1.SetField("Name", w.WptName);
                    g1.AddPoint_2D(w.Lon, w.Lat);
                    f1.SetGeometry(g1);
                    layer1.CreateFeature(f1);
                }

                //Write Routes

                Layer layer3 = ds.CreateLayer("route_points", wgs84, wkbGeometryType.wkbPoint, new string[] { });
                Feature f3 = new Feature(layer3.GetLayerDefn());
                OSGeo.OGR.Geometry g3 = new OSGeo.OGR.Geometry(wkbGeometryType.wkbPoint);

                for (int i =0 ;i<RouteList.Count;i++)
                {
                    for (int j = 0; j < RouteList[i].RteEntries.Count; j++)
                    {
                        Waypoint w = RouteList[i].RteEntries[j].ToWpt;
                        g3.AddPoint_2D(w.Lon, w.Lat);
                        f3.SetField("route_fid", i);
                        f3.SetField("route_point_id", j);
                        f3.SetField("route_name", RouteList[i].Name);
                        f3.SetField("name", w.WptName);
                        f3.SetGeometry(g3);
                        layer3.CreateFeature(f3);
                    }
                }
                
            }


        }
        
        private void GribLoadButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            dlg.Filter = "grib files|*.grb";
            dlg.InitialDirectory = Properties.Settings.Default.GribDirectory;
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                if (maploaded && wgrib != null)
                {
                    foreach (WindArrow wa in waGrid.windarrows)
                        content.Children.Remove(wa.path);
                }

                string filename = dlg.FileName;
                Properties.Settings.Default.GribDirectory = System.IO.Path.GetDirectoryName(filename);

                Dataset ds = Gdal.Open(filename, Access.GA_ReadOnly);

                wgrib = new windgrib(ref ds);

                Collection<uvpair> uvpairs = new Collection<uvpair>();  // Here uvpairs are used to correlate u&v bands

                for (int i = 1; i <= ds.RasterCount; i++)
                {
                    Band uband = ds.GetRasterBand(i);
                    if (uband.GetMetadataItem("GRIB_SHORT_NAME", "") == "10-HTGL")
                    {
                        string hhh = uband.GetMetadataItem("GRIB_ELEMENT", "");
                        if (uband.GetMetadataItem("GRIB_ELEMENT", "") == "UGRD")
                        {
                            string fcst_time = uband.GetMetadataItem("GRIB_FORECAST_SECONDS", "");
                            for (int j = 1; j <= ds.RasterCount; j++)
                            {
                                Band vband = ds.GetRasterBand(j);
                                if (vband.GetMetadataItem("GRIB_SHORT_NAME", "") == "10-HTGL")
                                    if (vband.GetMetadataItem("GRIB_ELEMENT", "") == "VGRD")
                                        if (vband.GetMetadataItem("GRIB_FORECAST_SECONDS", "") == fcst_time)
                                            uvpairs.Add(new uvpair { u = i, v = j });
                            }
                        }
                    }
                }

                foreach (uvpair uv in uvpairs)
                {
                    Band uband = ds.GetRasterBand((int)uv.u);
                    Band vband = ds.GetRasterBand((int)uv.v);

                    windband wb = new windband(ds.RasterXSize, ds.RasterYSize);

                    string[] s = uband.GetMetadataItem("GRIB_REF_TIME", "").Trim().Split(' ');
                    long secs = Convert.ToInt64(s[0]);
                    s = uband.GetMetadataItem("GRIB_FORECAST_SECONDS", "").Trim().Split(' ');
                    long offs = Convert.ToInt64(s[0]);
                    DateTime UnixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
                    wb.datetime = UnixEpoch + TimeSpan.FromMilliseconds(1000 * (secs+offs));

                    for (int j = 0; j < ds.RasterYSize; j++)
                        for (int i = 0; i < ds.RasterXSize; i++)
                        {
                            double[] buffer = new double[1];
                            uvpair valuepair = new uvpair();
                            uband.ReadRaster(i, j, 1, 1, buffer, 1, 1, 1, 1);
                            valuepair.u = buffer[0];
                            vband.ReadRaster(i, j, 1, 1, buffer, 1, 1, 1, 1);
                            valuepair.v = buffer[0];
                            double lat, lon;
                            wgrib.ConvertToLL(i, j, out lon, out lat);
                            valuepair.Lat = lat > 180 ? lat - 360 : lat;
                            valuepair.Lon = lon > 180 ? lon - 360 : lon;
                            wb.data[i,j]=valuepair;
                        }
                    wgrib.windbands.Add(wb);
                }

                waGrid = new WindArrowGrid(ref wgrib, ref map);
                gribControl.GribSlider.Maximum = wgrib.windbands.Count - 2;
                gribControl.GribWindCheck.IsEnabled = true;
                DrawWindArrows();
                SetGribTimeNow();

            }
        }
    
        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ChangeTimeAxis();
        }

        private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            MapImg.Opacity = OpacitySlider.Value / 15;
        }

        private void WriteToLog()
        {
            string s = DateTime.Now.ToLongTimeString() + "," + COG.FormattedValue + "," + HDT.FormattedValue + "," + SOG.FormattedValue
                + "," + SPD.FormattedValue + "," + AWA.FormattedValue + "," + AWS.FormattedValue;

            if (CommentLogged)
            {
                s += "," + Comment;
                CommentLogged = false;
            }
            LogFile.WriteLine(s);
        }

        private void ChangeTimeAxis()
        {
            TimeSpan ts = new TimeSpan(0, (int)slider1.Value * 15, 0);

            DateTime stime, etime;

            etime = DateTime.Now;
            stime = etime - ts;

            timeaxis1.Minimum = stime;
            timeaxis1.Maximum = etime;

            timeaxis2.Minimum = stime;
            timeaxis2.Maximum = etime;
        }

        private void zoomAndPanControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            content.Focus();

            var tt = (TranslateTransform)((TransformGroup)content.RenderTransform).Children.First(tr => tr is TranslateTransform);
            start = e.GetPosition(zoomAndPanControl);
            origin = new Point(tt.X, tt.Y);

            mouseButtonDown = e.ChangedButton;

            if (mouseButtonDown == MouseButton.Left)
            {
                // Just a plain old left-down initiates panning mode.
                if(mouseHandlingMode==MouseHandlingMode.MovingWaypoint)
                    mouseHandlingMode = MouseHandlingMode.MovingWptandPanning;
                else
                    mouseHandlingMode = MouseHandlingMode.Panning;

                // Capture the mouse so that we eventually receive the mouse up event.
                //zoomAndPanControl.CaptureMouse();
                //e.Handled = true;
            }
        }

        private void zoomAndPanControl_MouseUp(object sender, MouseButtonEventArgs e)
        {

            if (mouseHandlingMode == MouseHandlingMode.Panning)
            {
                zoomAndPanControl.ReleaseMouseCapture();
                mouseHandlingMode = MouseHandlingMode.None;
                //e.Handled = true;

                if ((bool)waypointControl.AddButton.IsChecked)
                {
                    if((start-e.GetPosition(zoomAndPanControl))==new Vector(0,0))
                    {
                        AddWaypoint(e.GetPosition(content));
                    }
                }

            }

            if (mouseHandlingMode == MouseHandlingMode.MovingWptandPanning)
            {
                if ((start - e.GetPosition(zoomAndPanControl)) == new Vector(0, 0))
                {
                    double lat, lon;
                    Point p = e.GetPosition(content);
                    map.ConvertToLL(p.X, p.Y, out lon, out lat);
                    MovingWpt.Lat = lat;
                    MovingWpt.Lon = lon;
                    
                    CalcRouteData();
                    routeControl.DataGrid1.Items.Refresh();
                    RepositionRoutes();

                    if (MovingWpt.WptName == WPT.FormattedValue)
                    {
                        WLAT.Val = lat;
                        WLAT.SetValid();
                        WLON.Val = lon;
                        WLON.SetValid();
                    }

                    if (MovingWpt.WptName == LWPT.FormattedValue)
                    {
                        LWLAT.Val = lat;
                        LWLAT.SetValid();
                        LWLON.Val = lon;
                        LWLON.SetValid();
                    }


                    zoomAndPanControl.ReleaseMouseCapture();
                    mouseHandlingMode = MouseHandlingMode.None;
                    //e.Handled = true;
                }
                else
                {
                    mouseHandlingMode = MouseHandlingMode.MovingWaypoint;
                }                
            }
        }

        private void zoomAndPanControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseHandlingMode == MouseHandlingMode.Panning)
            {
                var tt = (TranslateTransform)((TransformGroup)content.RenderTransform).Children.First(tr => tr is TranslateTransform);
                Vector v = start - e.GetPosition(zoomAndPanControl);
                tt.X = origin.X - v.X;
                tt.Y = origin.Y - v.Y;
                e.Handled = true;

                Properties.Settings.Default.MapX = tt.X;
                Properties.Settings.Default.MapY = tt.Y;
            }

            if (mouseHandlingMode == MouseHandlingMode.MovingWaypoint)
            {
                Point p = e.GetPosition(content);

                double lat, lon;
                map.ConvertToLL(p.X, p.Y, out lon, out lat);
                MovingWpt.Lat = lat;
                MovingWpt.Lon = lon;
                RepositionRoutes();
            }

            if (mouseHandlingMode == MouseHandlingMode.MovingWptandPanning)
            {
                var tt = (TranslateTransform)((TransformGroup)content.RenderTransform).Children.First(tr => tr is TranslateTransform);
                Vector v = start - e.GetPosition(zoomAndPanControl);
                tt.X = origin.X - v.X;
                tt.Y = origin.Y - v.Y;

                Point p = e.GetPosition(content);
                MovingWpt.SetPosition(p.X, p.Y);

                e.Handled = true;

                Properties.Settings.Default.MapX = tt.X;
                Properties.Settings.Default.MapY = tt.Y;
            }
        }

        private void zoomAndPanControl_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            TransformGroup transformGroup = (TransformGroup)content.RenderTransform;
            ScaleTransform st = (ScaleTransform)transformGroup.Children[0];
            TranslateTransform tt = (TranslateTransform)transformGroup.Children[1];
            //var tt = (TranslateTransform)((TransformGroup)content.RenderTransform).Children.First(tr => tr is TranslateTransform);

            double zoom = e.Delta > 0 ? 1.3 : (1 / 1.3);            

            Point relative = e.GetPosition(content);
            double abosuluteX;
            double abosuluteY;

            abosuluteX = relative.X * st.ScaleX + tt.X;
            abosuluteY = relative.Y * st.ScaleY + tt.Y;

            st.ScaleX *= zoom;
            st.ScaleY *= zoom;

            tt.X = abosuluteX - relative.X * st.ScaleX;
            tt.Y = abosuluteY - relative.Y * st.ScaleY;

            Properties.Settings.Default.MapScale = st.ScaleX;
            Properties.Settings.Default.MapX = tt.X;
            Properties.Settings.Default.MapY = tt.Y;
        }

        private void AddWaypointsToCanvas()
        {
            if (maploaded)
            {
                foreach (Waypoint w in WaypointList)
                {
                    double x, y;
                    map.ConvertToXY(w.Lon, w.Lat, out x, out y);
                    w.SetPosition(x, y);
                    content.Children.Add(w);
                }
            }
        }

        private void RepositionWaypoints()
        {
            if (maploaded)
            {
                foreach (Waypoint w in WaypointList)
                {
                    double x, y;
                    map.ConvertToXY(w.Lon, w.Lat, out x, out y);
                    w.SetPosition(x, y);
                }
            }
        }

        private void AddWaypoint(Point p)
        {
            if (maploaded)
            {
                double lat, lon;
                map.ConvertToLL(p.X, p.Y, out lon, out lat);
                wptnumber++;
                if (WaypointList.Count != 0)
                {
                    int i = 0;
                    while (i != WaypointList.Count)
                    {
                        if (WaypointList[i].WptName != wptnumber.ToString())
                            i++;
                        else
                        {
                            wptnumber++;
                            i = 0;
                        }
                    }
                }
                Waypoint wp = new Waypoint(wptnumber.ToString(), lat, lon);
                wp.WaypointHd+=new WaypointEventHandler(WaypointCommandReceived);
                WaypointList.Add(wp);
                int lastitem = WaypointList.Count - 1;
                WaypointList[lastitem].SetPosition(p.X, p.Y);
                content.Children.Add(WaypointList[WaypointList.Count - 1]);
            }
        }

        private void AddRoutesToCanvas()
        {
            if (maploaded)
            {
                foreach(Route r in RouteList)
                {
                    r.polyline.Points.Clear();
                    r.polyline.Points = CalcRoutePoints(r);
                    content.Children.Add(r.polyline);
                }
            }
        }
        
        private void RepositionRoutes()
        {
            if (maploaded)
            {
                foreach (Route r in RouteList)
                {
                    r.polyline.Points.Clear();
                    r.polyline.Points = CalcRoutePoints(r);
                    if (r == ActiveRoute)
                        r.SetActive();
                    else
                        r.SetInactive();
                }
            }
        }

        private void RepositionTrack()
        {
            if (maploaded)
            {
                track.TrackLine.Points.Clear();
                for (int k = 0; k < LAT.LongBuffer.Count; k++)
                {
                    double x, y;
                    map.ConvertToXY(LON.LongBuffer[k].Val, LAT.LongBuffer[k].Val, out x, out y);
                    track.TrackLine.Points.Add(new Point(x, y));
                }
            }
        }

        private void RepositionWindGrib()
        {
            if (wgrib != null)
            {
                foreach (WindArrow wa in waGrid.windarrows)
                    content.Children.Remove(wa.path);
                waGrid=new WindArrowGrid(ref wgrib,ref map);
                DrawWindArrows();
            }
        }
        
        private PointCollection CalcRoutePoints(Route route)
        {
            PointCollection pc = new PointCollection();
            if(route.RteEntries.Count>1)
            {
                foreach (rteEntry w in route.RteEntries)
                {
                    Point p = GetWaypointPosition(w.ToWpt);
                    pc.Add(p);
                }
            }
            return pc;
        }

        public Point GetWaypointPosition(Waypoint wpt)
        {            
            double lat = wpt.Lat;
            double lon = wpt.Lon;                        
            double x, y;
            map.ConvertToXY(lon, lat, out x, out y);
            return new Point(x, y);
        }

        public void WaypointCommandReceived(object sender, WaypointEventArgs e)
        {
            Waypoint sdr = sender as Waypoint;
            switch (e.Command)
            {
                #region Activate
                case WaypointCmd.Activate:
                    {
                        foreach (Waypoint wc in WaypointList)
                            wc.SetInactive();
                        Waypoint wpt = sdr;
                        wpt.SetActive();
                        WLAT.Val = wpt.Lat;
                        WLAT.SetValid();
                        WLON.Val = wpt.Lon;
                        WLON.SetValid();
                        WPT.FormattedValue = sdr.WptName;
                        WPT.SetValid();

                        // Search for waypoint in Route List, if found, activate route and calculate previous waypoint
                        bool wfound = false;
                        foreach (Route r in RouteList)
                        {
                            Waypoint lwpt = new Waypoint();
                            foreach (rteEntry rte_entry in r.RteEntries)
                            {
                                if (rte_entry.ToWpt == sdr)
                                {
                                    ActiveRoute = r;
                                    ActiveRoute.ActiveRteEntry = rte_entry;
                                    wfound = true;
                                    if (lwpt != null) // If there is a previous waypoint on the route, set as Last Waypoint
                                    {
                                        LWLAT.Val = lwpt.Lat;
                                        LWLAT.SetValid();
                                        LWLON.Val = lwpt.Lon;
                                        LWLON.SetValid();
                                        LWPT.FormattedValue = lwpt.WptName;
                                        LWPT.SetValid();
                                    }
                                    else
                                    {
                                        LWLAT.Invalidate();
                                        LWLON.Invalidate();
                                        LWPT.Invalidate();
                                    }
                                    break;
                                }
                                lwpt = rte_entry.ToWpt;
                            }
                        }
                        if (wfound)
                        {
                        }
                        else
                        {
                            ActiveRoute = null;
                            LWLAT.Invalidate();
                            LWLON.Invalidate();
                            LWPT.Invalidate();
                        }
                        CalcRouteData();
                        routeControl.DataGrid1.Items.Refresh();
                        RepositionRoutes();
                        break;
                    }
                
                #endregion

                #region Delete
                case WaypointCmd.Delete:
                    {
                        if(WPT.FormattedValue == sdr.WptName) // Trying to delete an active Waypoint
                        {
                            MessageBoxResult result = MessageBox.Show("Cannot delete an active Waypoint", "Warning");
                            break;
                        }

                        
                        // Delete Waypoint from routes

                        bool wptsToDelete = true;
                        foreach (Route r in RouteList)
                        {
                            while (wptsToDelete)
                            {
                                try
                                {
                                    r.RteEntries.Remove(r.RteEntries.First(re => re.ToWpt == sdr));
                                }
                                catch (Exception)
                                {
                                    wptsToDelete=false;
                                }
                            }
                        }                          

                        if (ActiveRoute != null)
                        {
                            int idx = ActiveRoute.RteEntries.IndexOf(ActiveRoute.ActiveRteEntry);
                            if (idx > 0) // There is a previous wpt
                            {
                                rteEntry lrte = ActiveRoute.RteEntries[idx - 1];
                                Waypoint lwpt = WaypointList.First(w => w == lrte.ToWpt);
                                LWPT.FormattedValue = lwpt.WptName;
                                LWPT.SetValid();
                                LWLAT.Val = lwpt.Lat;
                                LWLAT.SetValid();
                                LWLON.Val = lwpt.Lon;
                                LWLON.SetValid();
                            }
                            else // Active wpt is first wpt in the route
                            {
                                LWPT.Invalidate();
                                LWLAT.Invalidate();
                                LWLON.Invalidate();
                            }
                        }
                        
                        WaypointList.Remove(sdr);

                        content.Children.Remove(sdr);

                        CalcRouteData();
                        routeControl.DataGrid1.Items.Refresh();
                        RepositionRoutes();
                        break;
                    } 
                #endregion

                #region AddToRoute
                case WaypointCmd.AddtoRoute:
                    {
                        if (routeControl.RouteListComboBox.Items.Count != 0)
                        {
                            Route rt = RouteList.Find(r => r.Name == routeControl.RouteListComboBox.SelectedItem.ToString());
                            rt.RteEntries.Add(new rteEntry(sdr));
                            RepositionRoutes();
                        }

                        CalcRouteData();
                        routeControl.DataGrid1.Items.Refresh();
                        break;
                    }

                #endregion

                #region Move
                case WaypointCmd.Move:
                    {
                        zoomAndPanControl.CaptureMouse();
                        mouseHandlingMode = MouseHandlingMode.MovingWaypoint;
                        MovingWpt= sdr;
                        break;
                    }

                #endregion

                #region Reposition
                case WaypointCmd.Reposition:
                    {
                        if (maploaded)
                        {
                            double x, y;
                            map.ConvertToXY(sdr.Lon, sdr.Lat, out x, out y);
                            sdr.SetPosition(x, y); 
                        }
                        break;
                    }

                #endregion

            }
        }

        public void RouteCtrlCommandReceived(object sender, RouteCtrlEventArgs e)
        {
            switch (e.Command)
            {
                #region ActivateRoute
                case RouteCtrlCmd.ActivateRoute:
                    {
                        string routename = "";
                        if (ActiveRoute != null)
                        {
                            routename = ActiveRoute.Name;
                        }

                        if (e.RouteName != routename)
                        {
                            //Deactivate old Waypoint
                            if (WPT.IsValid())
                            {
                                Waypoint oldwpt = WaypointList.First(w => w.WptName == WPT.FormattedValue);
                                oldwpt.SetInactive();
                            }

                            ActiveRoute = RouteList.Find(r => r.Name == e.RouteName);
                            if (ActiveRoute.RteEntries.Count > 0)
                            {
                                ActiveRoute.ActiveRteEntry = ActiveRoute.RteEntries[0];
                                Waypoint wpt = ActiveRoute.RteEntries[0].ToWpt;
                                wpt.SetActive();
                                WLAT.Val = wpt.Lat;
                                WLAT.SetValid();
                                WLON.Val = wpt.Lon;
                                WLON.SetValid();
                                WPT.FormattedValue = wpt.WptName;
                                WPT.SetValid();
                                LWLAT.Invalidate();
                                LWLON.Invalidate();
                                LWPT.Invalidate();
                                LEGBRG.Invalidate();

                                CalcRouteData();
                                routeControl.DataGrid1.Items.Refresh();
                                RepositionRoutes();
                            }
                            else
                            {
                                WLAT.Invalidate();
                                WLON.Invalidate();
                                WPT.Invalidate();
                                LWLAT.Invalidate();
                                LWLON.Invalidate();
                                LWPT.Invalidate();
                                LEGBRG.Invalidate();
                            }
                        }
                        break;
                    } 
                #endregion

                #region SelectionChanged
                case RouteCtrlCmd.SelectionChanged:
                    {
                        SelectedRoute = RouteList.Find(r => r.Name == e.RouteName);
                        if (SelectedRoute != null)
                        {
                            CalcRouteData();
                            routeControl.DataContext = SelectedRoute.RteEntries;
                        }
                        break;
                    }
                #endregion

                #region NewRoute
                case RouteCtrlCmd.NewRoute:
                    {
                        int i = 0;
                        while (i < RouteList.Count)
                        {
                            if (RouteList[i].Name != "Route " + rtenumber.ToString())
                            {
                                i++;
                            }
                            else
                            {
                                rtenumber++;
                                i = 0;
                            }
                        }
                        string rname="Route "+rtenumber.ToString();
                        RouteList.Add(new Route(rname));
                        routeControl.RouteListComboBox.Items.Add(rname);
                        routeControl.RouteListComboBox.SelectedItem = rname;
                        routeControl.DataContext = RouteList[RouteList.Count - 1].RteEntries;
                        content.Children.Add(RouteList[RouteList.Count - 1].polyline);
                        break;
                    }
                #endregion

            }
        }
         
        private void Center_Button_Click(object sender, RoutedEventArgs e)
        {
            if (LAT.IsValid())
            {
                var tt = (TranslateTransform)((TransformGroup)content.RenderTransform).Children.First(tr => tr is TranslateTransform);
                TransformGroup transformGroup = (TransformGroup)content.RenderTransform;
                ScaleTransform st = (ScaleTransform)transformGroup.Children[0];

                double x0, y0;
                map.ConvertToXY(LON.Val, LAT.Val, out x0, out y0);

                tt.X = -x0 * st.ScaleX + zoomAndPanControl.ActualWidth / 2 ;
                tt.Y = -y0 * st.ScaleY + zoomAndPanControl.ActualHeight / 2;

                Properties.Settings.Default.MapX = tt.X;
                Properties.Settings.Default.MapY = tt.Y;
                              
            }
        }

        private void ZoomAll_Button_Click(object sender, RoutedEventArgs e)
        {
            ZoomAll();
        }

        private void ZoomAll()
        {
            var tt = (TranslateTransform)((TransformGroup)content.RenderTransform).Children.First(tr => tr is TranslateTransform);
            TransformGroup transformGroup = (TransformGroup)content.RenderTransform;
            ScaleTransform st = (ScaleTransform)transformGroup.Children[0];

            double sx = zoomAndPanControl.ActualWidth / map.Image.PixelWidth;
            double sy = zoomAndPanControl.ActualHeight / map.Image.PixelHeight;
            double scale = Math.Min(sx, sy);

            st.ScaleX = scale;
            st.ScaleY = scale;

            tt.X = -map.Image.PixelWidth / 2 * scale + zoomAndPanControl.ActualWidth / 2;
            tt.Y = -map.Image.PixelHeight / 2 * scale + zoomAndPanControl.ActualHeight / 2;

            Properties.Settings.Default.MapX = tt.X;
            Properties.Settings.Default.MapY = tt.Y;
            Properties.Settings.Default.MapScale = scale;
        }

        public void UpdateShapes()
        {
            if (maploaded)
            {
                if (LAT.IsValid())
                {
                    double x0, y0;
                    map.ConvertToXY(LON.Val, LAT.Val, out x0, out y0);
                    Canvas.SetLeft(Boat, x0);
                    Canvas.SetTop(Boat, y0);

                    double angle;
                    if (HDT.IsValid())
                        angle = HDT.Val;
                    else
                        angle = COG.Val;
                    BoatCourse.Angle = angle;

                    if (COG.IsValid() || HDT.IsValid())
                    {
                        bearingLine.SetPosition(x0, y0);
                        bearingLine.SetAngle(COG.Val);
                        bearingLine.line.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        bearingLine.line.Visibility = Visibility.Hidden;
                    }

                    if (TWD.IsValid())
                    {
                        windvane.SetPosition(x0, y0);
                        windvane.SetAngle(TWD.Average());
                        windvane.polygon.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        windvane.polygon.Visibility = Visibility.Hidden;
                    }

                    if (SET.IsValid())
                    {
                        driftvane.SetPosition(x0, y0);
                        driftvane.SetAngle(SET.Average() + 180);
                        driftvane.polygon.Visibility = Visibility.Visible;

                    }
                    else
                    {
                        driftvane.polygon.Visibility = Visibility.Hidden;
                    }

                    int idx = track.TrackLine.Points.Count;
                    if (idx > 0)
                    {
                        Point p = track.TrackLine.Points[idx - 1];
                        p.X = x0;
                        p.Y = y0;
                        track.TrackLine.Points[idx - 1] = p;
                    }

                    if (TGTCOGs.IsValid())
                    {
                        double x1, y1;
                        map.ConvertToXY(WLON.Val, WLAT.Val, out x1, out y1);
                        Layline_s.SetPosition(x1, y1);
                        Layline_p.SetPosition(x1, y1);

                        double len = Math.Sqrt(Math.Pow(x1 - x0, 2) + Math.Pow(y1 - y0, 2)) * 1.5;
                        Layline_s.SetLength(len);
                        Layline_p.SetLength(len);

                        Layline_s.SetAngle(TGTCOGp.Val + 180);
                        Layline_p.SetAngle(TGTCOGs.Val + 180);

                        Layline_s.line.Visibility = Visibility.Visible;
                        Layline_p.line.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        Layline_s.line.Visibility = Visibility.Hidden;
                        Layline_p.line.Visibility = Visibility.Hidden;
                    }                    
                }
            }
        }

        public void DrawWindArrows()
        {

            waGrid.Update(ref wgrib, DateTime.UtcNow);

            foreach (WindArrow wa in waGrid.windarrows)
            {
                content.Children.Add(wa.path);
                if (!(bool)gribControl.GribWindCheck.IsChecked)
                    wa.path.Visibility = Visibility.Hidden;
            }

        }

        private void GribSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (wgrib != null)
            {
                double ts = (wgrib.windbands[wgrib.windbands.Count - 1].datetime - wgrib.windbands[0].datetime).TotalSeconds * gribControl.GribSlider.Value / (gribControl.GribSlider.Maximum+1);
                DateTime dt = wgrib.windbands[0].datetime + TimeSpan.FromSeconds(ts);                
                waGrid.Update(ref wgrib, dt);
                gribControl.textblock.Text = dt.ToLocalTime().ToString();
            }
        }

        private void GribNowButton_Click(object sender, RoutedEventArgs e)
        {
            SetGribTimeNow();            
        }

        private void SetGribTimeNow()
        {
            if (wgrib != null)
            {
                DateTime dt = DateTime.Now.ToUniversalTime();
                if (dt >= wgrib.windbands[0].datetime && dt <= wgrib.windbands[wgrib.windbands.Count - 1].datetime)
                {
                    gribControl.GribSlider.Value = (dt - wgrib.windbands[0].datetime).TotalSeconds / (wgrib.windbands[wgrib.windbands.Count - 1].datetime - wgrib.windbands[0].datetime).TotalSeconds * (gribControl.GribSlider.Maximum + 1);
                    waGrid.Update(ref wgrib, dt);
                    gribControl.textblock.Text = dt.ToLocalTime().ToString();
                }
            }
        }

        private void Routes_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)RoutesToggleButton.IsChecked)
            {
                if ((bool)GribToggleButton.IsChecked)
                {
                    ControlGrid.Children.Remove(gribControl);
                    GribToggleButton.IsChecked = false;
                }
                if ((bool)WaypointsToggleButton.IsChecked)
                {
                    ControlGrid.Children.Remove(waypointControl);
                    WaypointsToggleButton.IsChecked = false;
                }
                Grid.SetRow(routeControl, 0);
                ControlGrid.Children.Add(routeControl);
            }
            else
            {
                ControlGrid.Children.Remove(routeControl);
            }
        }

        private void Waypoints_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)WaypointsToggleButton.IsChecked)
            {
                if ((bool)RoutesToggleButton.IsChecked)
                {
                    ControlGrid.Children.Remove(routeControl);
                    RoutesToggleButton.IsChecked = false;
                }
                if ((bool)GribToggleButton.IsChecked)
                {
                    ControlGrid.Children.Remove(gribControl);
                    GribToggleButton.IsChecked = false;
                }
                Grid.SetRow(waypointControl, 0);
                Grid.SetIsSharedSizeScope(waypointControl, true);
                ControlGrid.Children.Add(waypointControl);
            }
            else
            {
                ControlGrid.Children.Remove(waypointControl);
            }

        }

        private void grib_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)GribToggleButton.IsChecked)
            {
                if ((bool)RoutesToggleButton.IsChecked)
                {
                    ControlGrid.Children.Remove(routeControl);
                    RoutesToggleButton.IsChecked = false;
                }
                if ((bool)WaypointsToggleButton.IsChecked)
                {
                    ControlGrid.Children.Remove(waypointControl);
                    WaypointsToggleButton.IsChecked = false;
                }
                Grid.SetRow(gribControl, 0);
                ControlGrid.Children.Add(gribControl);
            }
            else
            {
                ControlGrid.Children.Remove(gribControl);
            }
        }

        private void GribWindCheck_Click(object sender, RoutedEventArgs e)
        {
            if (waGrid != null)
            {
                if ((bool)gribControl.GribWindCheck.IsChecked)
                {
                    foreach (WindArrow wa in waGrid.windarrows)
                        wa.path.Visibility = Visibility.Visible;
                }
                else
                {
                    foreach (WindArrow wa in waGrid.windarrows)
                        wa.path.Visibility = Visibility.Hidden;
                }
            }
        }

        private void MapsButton_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)MapsButton.IsChecked)
            {
                mapindex.SetRectangles(ref map);

                foreach (MapEntry me in mapindex.Maps)
                    content.Children.Add(me);
                waypointControl.AddButton.IsChecked = false;
                zoomAndPanControl.Cursor = Cursors.Arrow;
            }
            else
            {
                foreach (MapEntry me in mapindex.Maps)
                    content.Children.Remove(me);
            }

        }
        
        public void MapEntry_click(object sender, MapEntryEventArgs e)
        {
            zoomAndPanControl.ReleaseMouseCapture();
            mouseHandlingMode = MouseHandlingMode.None;

            foreach (MapEntry me in mapindex.Maps)
                content.Children.Remove(me);
            MapsButton.IsChecked = false;
            LoadMap(e.Filename);
        }

        private void IndexMaps_Click(object sender, RoutedEventArgs e)
        {
            string foldername = Properties.Settings.Default.MapsDirectory;

            if (foldername != "")
            {                
                MainWnd.Cursor = Cursors.Wait;

                foreach (string filename in Directory.GetFiles(foldername, "*.kap"))
                {
                    Dataset ds = Gdal.Open(filename, Access.GA_ReadOnly);

                    // Read projected coordinate system and create 
                    string geopref = ds.GetProjectionRef();

                    if (geopref != "")
                    {
                        SpatialReference sr = new SpatialReference(geopref);
                        string wkt;
                        Osr.GetWellKnownGeogCSAsWKT("WGS84", out wkt);
                        SpatialReference wgs84 = new SpatialReference(wkt);


                        CoordinateTransformation transform_to_latlon = new CoordinateTransformation(sr, wgs84);

                        // Read Geo Transform coefficients from dataset and calculate inverse
                        double[] gtCoef = new double[6];
                        ds.GetGeoTransform(gtCoef);

                        double[] v = new double[3];
                        double x, y;

                        Gdal.ApplyGeoTransform(gtCoef, 0, 0, out  x, out y);
                        transform_to_latlon.TransformPoint(v, x, y, 0);
                        double lon0 = v[0];
                        double lat0 = v[1];

                        Gdal.ApplyGeoTransform(gtCoef, ds.RasterXSize - 1, ds.RasterYSize - 1, out  x, out y);
                        transform_to_latlon.TransformPoint(v, x, y, 0);
                        double lon1 = v[0];
                        double lat1 = v[1];

                        MapEntry me = new MapEntry(lat0, lon0, lat1, lon1, ds.GetDescription(), filename);
                        me.MapEntryHd += new MapEntryEventHandler(MapEntry_click);
                        mapindex.Maps.Add(me);
                    }

                }
                MainWnd.Cursor = Cursors.Arrow;

                SaveMapIndex();
            }


        }

        public void LoadMapIndex()
        {
            string foldername = Properties.Settings.Default.MapsDirectory;

            if (foldername != "")
            {
                
                mapindex.Maps.Clear();

                XmlDocument doc = new XmlDocument();

                doc.Load(foldername + "\\mapindex.xml");

                XmlNodeList mapNodes = doc.SelectNodes("//Maps/Map");
                foreach (XmlNode mapNode in mapNodes)
                {
                    double minLat = double.Parse(mapNode.Attributes["minLat"].Value);
                    double maxLat = double.Parse(mapNode.Attributes["maxLat"].Value);
                    double minLon = double.Parse(mapNode.Attributes["minLon"].Value);
                    double maxLon = double.Parse(mapNode.Attributes["maxLon"].Value);
                    string filename = mapNode.InnerText;

                    MapEntry me = new MapEntry(minLat, minLon, maxLat, maxLon, filename, filename);
                    me.MapEntryHd += new MapEntryEventHandler(MapEntry_click);
                    mapindex.Maps.Add(me);

                }

                if (maploaded)
                    mapindex.SetRectangles(ref map);
            }
        }

        public void SaveMapIndex()
        {

            string foldername = Properties.Settings.Default.MapsDirectory;

            if (foldername != "")
            {
                XmlDocument doc = new XmlDocument();
                XmlNode rootNode, mapNode, comment;
                XmlAttribute minLat, minLon, maxLat, maxLon;

                comment = doc.CreateComment("LionRiver Map Index");
                doc.AppendChild(comment);

                rootNode = doc.CreateElement("Maps");
                doc.AppendChild(rootNode);

                foreach (MapEntry me in mapindex.Maps)
                {
                    mapNode = doc.CreateElement("Map");
                    mapNode.InnerText = me.filename;
                    rootNode.AppendChild(mapNode);

                    minLat = doc.CreateAttribute("minLat");
                    minLat.Value = me.minLat.ToString();
                    mapNode.Attributes.Append(minLat);

                    minLon = doc.CreateAttribute("minLon");
                    minLon.Value = me.minLon.ToString();
                    mapNode.Attributes.Append(minLon);

                    maxLat = doc.CreateAttribute("maxLat");
                    maxLat.Value = me.maxLat.ToString();
                    mapNode.Attributes.Append(maxLat);

                    maxLon = doc.CreateAttribute("maxLon");
                    maxLon.Value = me.maxLon.ToString();
                    mapNode.Attributes.Append(maxLon);
                }

                doc.Save(foldername + "\\mapindex.xml");

            }

        }

        void Waypoint_AddButton_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)waypointControl.AddButton.IsChecked)
            {
                zoomAndPanControl.Cursor = Cursors.Cross;
                if ((bool)MapsButton.IsChecked)
                {
                    MapsButton.IsChecked = false;
                    foreach (MapEntry me in mapindex.Maps)
                        content.Children.Remove(me);
                }
            }
            else
                zoomAndPanControl.Cursor = Cursors.Arrow;
        }
    }
}
