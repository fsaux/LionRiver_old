﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Threading;

namespace LionRiver
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        static SerialPort SerialPort1, SerialPort2, SerialPort3, SerialPort4;
        static bool terminateThread1, terminateThread2, terminateThread3, terminateThread4;
        Thread readThread1, readThread2, readThread3, readThread4;

        public void InitializeSerialPort1()
        {
            try
            {
                SerialPort1.PortName = Properties.Settings.Default.Port1;
            }
            catch (ArgumentException) { }
            SerialPort1.BaudRate = 4800;
            SerialPort1.Parity = Parity.None;
            SerialPort1.DataBits = 8;
            SerialPort1.StopBits = StopBits.One;
            SerialPort1.Handshake = Handshake.RequestToSend;
            SerialPort1.ReadTimeout = 2000;
            SerialPort1.WriteTimeout = 2000;

            try
            {
                SerialPort1.Open();
            }
            catch (Exception) {}
        }

        public void InitializeSerialPort2()
        {
            try
            {
                SerialPort2.PortName = Properties.Settings.Default.Port2;
            }
            catch (ArgumentException) { }
            SerialPort2.BaudRate = 4800;
            SerialPort2.Parity = Parity.None;
            SerialPort2.DataBits = 8;
            SerialPort2.StopBits = StopBits.One;
            SerialPort2.Handshake = Handshake.RequestToSend;
            SerialPort2.ReadTimeout = 2000;
            SerialPort2.WriteTimeout = 2000;

            try
            {
                SerialPort2.Open();
            }
            catch (Exception) { }
        }

        public void InitializeSerialPort3()
        {
            try
            {
                SerialPort3.PortName = Properties.Settings.Default.Port3;
            }
            catch (ArgumentException) { }
            SerialPort3.BaudRate = 4800;
            SerialPort3.Parity = Parity.None;
            SerialPort3.DataBits = 8;
            SerialPort3.StopBits = StopBits.One;
            SerialPort3.Handshake = Handshake.RequestToSend;
            SerialPort3.ReadTimeout = 2000;
            SerialPort3.WriteTimeout = 2000;

            try
            {
                SerialPort3.Open();
            }
            catch (Exception) { }
        }

        public void InitializeSerialPort4()
        {
            try
            {
                SerialPort4.PortName = Properties.Settings.Default.Port4;
            }
            catch (ArgumentException) { }
            SerialPort4.BaudRate = 4800;
            SerialPort4.Parity = Parity.None;
            SerialPort4.DataBits = 8;
            SerialPort4.StopBits = StopBits.One;
            SerialPort4.Handshake = Handshake.RequestToSend;
            SerialPort4.ReadTimeout = 2000;
            SerialPort4.WriteTimeout = 2000;

            try
            {
                SerialPort4.Open();
            }
            catch (Exception) { }
        }

        public void CloseSerialPort1()
        {
            terminateThread1 = true;
            readThread1.Join();
            SerialPort1.Close();
        }

        public void CloseSerialPort2()
        {
            terminateThread2 = true;
            readThread2.Join();
            SerialPort2.Close();
        }

        public void CloseSerialPort3()
        {
            terminateThread3 = true;
            readThread3.Join();
            SerialPort3.Close();
        }

        public void CloseSerialPort4()
        {
            terminateThread4 = true;
            readThread4.Join();
            SerialPort4.Close();
        }

        public static void ReadSerial1()
        {
            string message = "";
            while (!terminateThread1)
            {
                if (SerialPort1.IsOpen)
                {
                    try
                    {
                        message = SerialPort1.ReadLine();                       
                    }
                    catch (Exception)
                    {
                        message="";
                    }
                    ProcessNMEA(message,1);
                }
                else
                    Thread.Sleep(1000);
            }
        }

        public static void ReadSerial2()
        {
            string message = "";
            while (!terminateThread2)
            {
                if (SerialPort2.IsOpen)
                {
                    try
                    {
                        message = SerialPort2.ReadLine();
                    }
                    catch (Exception)
                    {
                        message = "";
                    }
                    ProcessNMEA(message,2);
                }
                else
                    Thread.Sleep(1000);
            }
        }

        public static void ReadSerial3()
        {
            string message = "";
            while (!terminateThread3)
            {
                if (SerialPort3.IsOpen)
                {
                    try
                    {
                        message = SerialPort3.ReadLine();
                    }
                    catch (Exception)
                    {
                        message = "";
                    }
                    ProcessNMEA(message, 3);
                }
                else
                    Thread.Sleep(1000);
            }
        }

        public static void ReadSerial4()
        {
            string message = "";
            while (!terminateThread4)
            {
                if (SerialPort4.IsOpen)
                {
                    try
                    {
                        message = SerialPort4.ReadLine();
                    }
                    catch (Exception)
                    {
                        message = "";
                    }
                    ProcessNMEA(message, 4);
                }
                else
                    Thread.Sleep(1000);
            }
        }

        static public void GetPosition(double Lat, double Lon, double Spd, double Hdg, double Mag, double Alt)
        {
            if (Properties.Settings.Default.GPSonOzi)
            {
                COG.Val = Hdg;
                SOG.Val = Spd / 1.852;
                LAT.Val = Lat;
                LON.Val = Lon;
                MVAR.Val = Mag;

                COG.SetValid();
                SOG.SetValid();
                LAT.SetValid();
                LON.SetValid();
                MVAR.SetValid();
            }

            DataReceivedFromOzi = true;

        }

        static public void GetNavData()
        {
            string sname="               ",descr="                ";
            double dist=0,brg=0;

            if (OziRunning)
            {
                Oziexplorer.oziGps2NavWp(ref sname, ref descr, ref dist, ref brg);

                if (sname != "")
                {
                    if (sname != WPT.FormattedValue)
                    {
                        if (WPT.IsValid())
                        {
                            LWPT.FormattedValue = WPT.FormattedValue;
                            LWLAT.Val = WLAT.Val;
                            LWLON.Val = WLON.Val;
                            LWPT.SetValid();
                        }

                        double nlat = 0, nlon = 0;
                        CalcPosition(LAT.Val, LON.Val, dist, brg, ref nlat, ref nlon);

                        WLAT.Val = nlat;
                        WLON.Val = nlon;

                        if (LWPT.IsValid())
                        {
                            LEGBRG.Val = CalcBearing(LWLAT.Val, LWLON.Val, WLAT.Val, WLON.Val);
                            LEGBRG.SetValid();
                        }
                    }

                    WPT.FormattedValue = sname;
                    WPT.SetValid();
                }
            }
        }

        static public void ProcessNMEA(string message,int port)
        {

            if (message!="")
            {

                string[] msg = message.Split(',');

                string NMEASentence;
                try
                {
                    NMEASentence = msg[0].Substring(3, 3);
                }
                catch (Exception)
                {
                    NMEASentence = "";
                }

                switch (NMEASentence)
                {
                    case "RMC":
                        if (port == 1 && Properties.Settings.Default.RMC.InPort == 0 ||
                            port == 2 && Properties.Settings.Default.RMC.InPort == 1 ||
                            port == 3 && Properties.Settings.Default.RMC.InPort == 2 ||
                            port == 4 && Properties.Settings.Default.RMC.InPort == 3)
                        {
                            try
                            {
                                LAT.Val = ConvertToDeg(msg[3]);
                                if (msg[4] == "S")
                                    LAT.Val = -LAT.Val;
                                LON.Val = ConvertToDeg(msg[5]);
                                if (msg[6] == "W")
                                    LON.Val = -LON.Val;
                                SOG.Val = double.Parse(msg[7]);
                                COG.Val = double.Parse(msg[8]);
                                if (msg[10] != "")
                                {
                                    MVAR.Val = double.Parse(msg[10]);
                                    if (msg[11].Substring(1, 1) == "W")
                                        MVAR.Val = -MVAR.Val;
                                    MVAR.SetValid();
                                }
                                LAT.SetValid();
                                LON.SetValid();
                                SOG.SetValid();
                                COG.SetValid();
                            }
                            catch (Exception) { }

                            if (port == 1) DataReceivedOnNMEA1 = true;
                            if (port == 2) DataReceivedOnNMEA2 = true;
                            if (port == 3) DataReceivedOnNMEA3 = true;
                            if (port == 4) DataReceivedOnNMEA4 = true;
                        }
                        break;


                    case "VHW":
                        if (port == 1 && Properties.Settings.Default.VHW.InPort == 0 ||
                            port == 2 && Properties.Settings.Default.VHW.InPort == 1 ||
                            port == 3 && Properties.Settings.Default.VHW.InPort == 2 ||
                            port == 4 && Properties.Settings.Default.VHW.InPort == 3)
                        {
                            try
                            {
                                SPD.Val = double.Parse(msg[5]);
                                SPD.SetValid();
                            }
                            catch (Exception) { }
                            if (port == 1) DataReceivedOnNMEA1 = true;
                            if (port == 2) DataReceivedOnNMEA2 = true;
                            if (port == 3) DataReceivedOnNMEA3 = true;
                            if (port == 4) DataReceivedOnNMEA4 = true;
                        }
                        break;

                    case "DBT":
                        if (port == 1 && Properties.Settings.Default.DBT.InPort == 0 ||
                            port == 2 && Properties.Settings.Default.DBT.InPort == 1 ||
                            port == 3 && Properties.Settings.Default.DBT.InPort == 2 ||
                            port == 4 && Properties.Settings.Default.DBT.InPort == 3)
                        {
                            try
                            {
                                DPT.Val = double.Parse(msg[3]);
                                DPT.SetValid();
                            }
                            catch (Exception) { }

                            if (port == 1) DataReceivedOnNMEA1 = true;
                            if (port == 2) DataReceivedOnNMEA2 = true;
                            if (port == 3) DataReceivedOnNMEA3 = true;
                            if (port == 4) DataReceivedOnNMEA4 = true;
                        }
                        break;

                    case "MWV":
                        if (port == 1 && Properties.Settings.Default.MWV.InPort == 0 ||
                            port == 2 && Properties.Settings.Default.MWV.InPort == 1 ||
                            port == 3 && Properties.Settings.Default.MWV.InPort == 2 ||
                            port == 4 && Properties.Settings.Default.MWV.InPort == 3)
                        {
                            if (msg[2] == "R")
                            {
                                try
                                {
                                    AWA.Val = double.Parse(msg[1]);
                                    AWS.Val = double.Parse(msg[3]);
                                    switch (msg[4])
                                    {
                                        case "N":
                                            break;
                                        case "K":
                                            AWS.Val = AWS.Val / 1.852;
                                            break;
                                    }
                                    AWA.SetValid();
                                    AWS.SetValid();
                                }
                                catch (Exception) { }

                                if (port == 1) DataReceivedOnNMEA1 = true;
                                if (port == 2) DataReceivedOnNMEA2 = true;
                                if (port == 3) DataReceivedOnNMEA3 = true;
                                if (port == 4) DataReceivedOnNMEA4 = true;
                            }
                        }
                        break;

                    case "HDG":
                        if (port == 1 && Properties.Settings.Default.HDG.InPort == 0 ||
                            port == 2 && Properties.Settings.Default.HDG.InPort == 1 ||
                            port == 3 && Properties.Settings.Default.HDG.InPort == 2 ||
                            port == 4 && Properties.Settings.Default.HDG.InPort == 3)
                        {
                            try
                            {
                                double mv = 0;
                                HDT.Val = double.Parse(msg[1]);
                                if (MVAR.IsValid())
                                    mv = MVAR.Val;
                                else
                                {
                                    if (msg[4] != "")
                                    {
                                        mv = double.Parse(msg[4]);
                                        if (msg[5].Substring(1, 1) == "W")
                                            mv = -mv;
                                        MVAR.SetValid();
                                    }
                                }
                                HDT.Val += mv + Properties.Settings.Default.MagVar;
                                HDT.SetValid();
                            }
                            catch (Exception) { }

                            if (port == 1) DataReceivedOnNMEA1 = true;
                            if (port == 2) DataReceivedOnNMEA2 = true;
                            if (port == 3) DataReceivedOnNMEA3 = true;
                            if (port == 4) DataReceivedOnNMEA4 = true;
                        }
                        break;

                    case "MTW":
                        if (port == 1 && Properties.Settings.Default.MTW.InPort == 0 ||
                            port == 2 && Properties.Settings.Default.MTW.InPort == 1 ||
                            port == 3 && Properties.Settings.Default.MTW.InPort == 2 ||
                            port == 4 && Properties.Settings.Default.MTW.InPort == 3)
                        {
                            try
                            {
                                TEMP.Val = double.Parse(msg[1]);
                                TEMP.SetValid();
                            }
                            catch (Exception) { }

                            if (port == 1) DataReceivedOnNMEA1 = true;
                            if (port == 2) DataReceivedOnNMEA2 = true;
                            if (port == 3) DataReceivedOnNMEA3 = true;
                            if (port == 4) DataReceivedOnNMEA4 = true;
                        }
                        break;
                }
                
            }                
        }

        public void SendNMEA()
        {
            string message;

            // Build MWV Sentence ****************************************************************************************
            
            if (AWA.IsValid())
            {

                message = "IIMWV," + ((AWA.Val+360)%360).ToString("#.#") + ",R," + AWS.Val.ToString("#.#") + ",N,A";

                int checksum = 0;

                foreach (char c in message)
                    checksum ^= Convert.ToByte(c);

                message = "$" + message + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.MWV.OutPort1)
                    if(SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message);
                if (Properties.Settings.Default.MWV.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message);
                if (Properties.Settings.Default.MWV.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message);
                if (Properties.Settings.Default.MWV.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message); 
            }

            // Build VHW Sentence ****************************************************************************************

            if (SPD.IsValid())
            {
                string hdg;
                if (HDT.IsValid())
                    hdg = HDT.Val.ToString("#.#") + ",T,,M,";
                else
                    hdg = ",T,,M,";

                message = "IIVHW," + hdg + SPD.Val.ToString("0.00") + ",N,,K";

                int checksum = 0;

                foreach (char c in message)
                    checksum ^= Convert.ToByte(c);

                message = "$" + message + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.VHW.OutPort1)
                    if (SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message);
                if (Properties.Settings.Default.VHW.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message);
                if (Properties.Settings.Default.VHW.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message);
                if (Properties.Settings.Default.VHW.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message);    
            }

            // Build DPT Sentence ****************************************************************************************

            if (DPT.IsValid())
            {

                message = "IIDPT,"+DPT.Val.ToString("0.00")+",0";

                int checksum = 0;

                foreach (char c in message)
                    checksum ^= Convert.ToByte(c);

                message = "$" + message + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.DBT.OutPort1)
                    if (SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message);
                if (Properties.Settings.Default.DBT.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message);
                if (Properties.Settings.Default.DBT.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message);
                if (Properties.Settings.Default.DBT.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message); 
            }

            // Build RMC Sentence ****************************************************************************************

            if (COG.IsValid())   // Implies SOG, LAT and LON are also valid
            {

                DateTime UTC = DateTime.UtcNow;

                string hms = UTC.Hour.ToString("00") + UTC.Minute.ToString("00") + UTC.Second.ToString("00.00");
                string date = UTC.Date.Day.ToString("00") + UTC.Date.Month.ToString("00") + UTC.Date.Year.ToString().Substring(2, 2);

                double deg, min;
                string cd;
 
                deg = Math.Abs(Math.Truncate(LAT.Val));
                min = (Math.Abs(LAT.Val) - deg) * 60;

                if (LAT.Val > 0)
                    cd = "N";
                else
                    cd = "S";

                string lat = deg.ToString("000")+min.ToString("00.00000")+","+cd;

                deg = Math.Abs(Math.Truncate(LON.Val));
                min = (Math.Abs(LON.Val) - deg) * 60;

                if (LON.Val > 0)
                    cd = "E";
                else
                    cd = "W";

                string lon = deg.ToString("000")+min.ToString("00.00000")+","+cd;

                if (MVAR.Val > 0)
                    cd = "E";
                else
                    cd = "W";

                message = "IIRMC,"+hms+",A,"+lat+","+lon+","+SOG.Val.ToString("0.00")+","+COG.Val.ToString("0.0")+","
                    +date+","+Math.Abs(MVAR.Val).ToString("0.0")+","+cd;

                int checksum = 0;

                foreach (char c in message)
                    checksum ^= Convert.ToByte(c);

                message = "$" + message + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.RMC.OutPort1)
                    if (SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message);
                if (Properties.Settings.Default.RMC.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message);
                if (Properties.Settings.Default.RMC.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message);
                if (Properties.Settings.Default.RMC.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message); 
            }

            // Build RMB Sentence ****************************************************************************************

            if (WPT.IsValid())   // Implies BRG and DST are also valid
            {
                string xte=",,";
                string owpt=",";

                if (XTE.IsValid())
                {
                    if (XTE.Val > 0)
                        xte = XTE.Val.ToString("0.00") + ",R,";
                    else
                        xte = Math.Abs(XTE.Val).ToString("0.00") + ",L,";
                    owpt = LWPT.FormattedValue + ",";
                }

                message = "IIRMB,A," + xte + owpt + WPT.FormattedValue + ",,,,," + DST.Val.ToString("#.##") + "," + BRG.Val.ToString("#.#")
                    + "," + VMGWPT.Val.ToString("0.00") + ",,";

                int checksum = 0;

                foreach (char c in message)
                    checksum ^= Convert.ToByte(c);

                message = "$" + message + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.RMB.OutPort1)
                    if (SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message);
                if (Properties.Settings.Default.RMB.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message);
                if (Properties.Settings.Default.RMB.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message);
                if (Properties.Settings.Default.RMB.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message); 
            }

            // Build MTW Sentence ****************************************************************************************

            if (TEMP.IsValid())
            {

                message = "IIMTW," + TEMP.Val.ToString("0.0") + ",C";

                int checksum = 0;

                foreach (char c in message)
                    checksum ^= Convert.ToByte(c);

                message = "$" + message + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.MTW.OutPort1)
                    if (SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message);
                if (Properties.Settings.Default.MTW.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message);
                if (Properties.Settings.Default.MTW.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message);
                if (Properties.Settings.Default.MTW.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message); 
            }
            
            if (LINEDST.IsValid())
            {

                string message4;

                message4 = "PTAK,FFD4," + LINEDST.Val.ToString("0");

                int checksum = 0;

                foreach (char c in message4)
                    checksum ^= Convert.ToByte(c);
                message4 = "$" + message4 + "*" + checksum.ToString("X2") + "\r\n";

                if (Properties.Settings.Default.PTAK.OutPort1)
                    if (SerialPort1.IsOpen)
                        SerialPort1.WriteLine(message4);
                if (Properties.Settings.Default.PTAK.OutPort2)
                    if (SerialPort2.IsOpen)
                        SerialPort2.WriteLine(message4);
                if (Properties.Settings.Default.PTAK.OutPort3)
                    if (SerialPort3.IsOpen)
                        SerialPort3.WriteLine(message4);
                if (Properties.Settings.Default.PTAK.OutPort4)
                    if (SerialPort4.IsOpen)
                        SerialPort4.WriteLine(message4); 
            }
        }

        public void SendPerformanceNMEA()
        {

            // Build PTAK Sentence ****************************************************************************************

            if (PERF.IsValid())
            {

                string message1, message2, message3, message5, message6;

                message1 = "PTAK,FFD1," + TGTSPD.Val.ToString("0.0");
                message2 = "PTAK,FFD2," + TGTTWA.Val.ToString("0") + "@";
                double pf = PERF.Val * 100;
                message3 = "PTAK,FFD3," + pf.ToString("0");
                message5 = "PTAK,FFD5," + TGTVMC.Val.ToString("0.0");
                message6 = "PTAK,FFD6," + TGTCTS.Val.ToString("0") + "@";

                int checksum = 0;

                checksum = 0;
                foreach (char c in message1)
                    checksum ^= Convert.ToByte(c);
                message1 = "$" + message1 + "*" + checksum.ToString("X2") + "\r\n";

                checksum = 0;
                foreach (char c in message2)
                    checksum ^= Convert.ToByte(c);
                message2 = "$" + message2 + "*" + checksum.ToString("X2") + "\r\n";

                checksum = 0;
                foreach (char c in message3)
                    checksum ^= Convert.ToByte(c);
                message3 = "$" + message3 + "*" + checksum.ToString("X2") + "\r\n";

                checksum = 0;
                foreach (char c in message5)
                    checksum ^= Convert.ToByte(c);
                message5 = "$" + message5 + "*" + checksum.ToString("X2") + "\r\n";

                checksum = 0;
                foreach (char c in message6)
                    checksum ^= Convert.ToByte(c);
                message6 = "$" + message6 + "*" + checksum.ToString("X2") + "\r\n";


                if (Properties.Settings.Default.PTAK.OutPort1)
                    if (SerialPort1.IsOpen)
                    {
                        SerialPort1.WriteLine(message1);
                        SerialPort1.WriteLine(message2);
                        SerialPort1.WriteLine(message3);
                        SerialPort1.WriteLine(message5);
                        SerialPort1.WriteLine(message6);
                    }
                if (Properties.Settings.Default.PTAK.OutPort2)
                    if (SerialPort2.IsOpen)
                    {
                        SerialPort2.WriteLine(message1);
                        SerialPort2.WriteLine(message2);
                        SerialPort2.WriteLine(message3);
                        SerialPort2.WriteLine(message5);
                        SerialPort2.WriteLine(message6);
                    }
                if (Properties.Settings.Default.PTAK.OutPort3)
                    if (SerialPort3.IsOpen)
                    {
                        SerialPort3.WriteLine(message1);
                        SerialPort3.WriteLine(message2);
                        SerialPort3.WriteLine(message3);
                        SerialPort3.WriteLine(message5);
                        SerialPort3.WriteLine(message6);
                    }
                if (Properties.Settings.Default.PTAK.OutPort4)
                    if (SerialPort4.IsOpen)
                    {
                        SerialPort4.WriteLine(message1);
                        SerialPort4.WriteLine(message2);
                        SerialPort4.WriteLine(message3);
                        SerialPort4.WriteLine(message5);
                        SerialPort4.WriteLine(message6);
                    }
            }
        }

        public void SendPTAKheaders()
        {
            string message1, message2, message3, message4, message5, message6;

            message1 = "PTAK,FFP1,TgtSPD, KNOTS";
            message2 = "PTAK,FFP2,TgtTWA, TRUE";
            message3 = "PTAK,FFP3,Perf, %";
            message4 = "PTAK,FFP4,Toline,METRES";
            message5 = "PTAK,FFP5,TgtVMC, KNOTS";
            message6 = "PTAK,FFP6,TgtCTS, TRUE";

            int checksum = 0;

            foreach (char c in message1)
                checksum ^= Convert.ToByte(c);
            message1 = "$" + message1 + "*" + checksum.ToString("X2") + "\r\n";

            checksum = 0;
            foreach (char c in message2)
                checksum ^= Convert.ToByte(c);
            message2 = "$" + message2 + "*" + checksum.ToString("X2") + "\r\n";

            checksum = 0; 
            foreach (char c in message3)
                checksum ^= Convert.ToByte(c);
            message3 = "$" + message3 + "*" + checksum.ToString("X2") + "\r\n";

            checksum = 0; 
            foreach (char c in message4)
                checksum ^= Convert.ToByte(c);
            message4 = "$" + message4 + "*" + checksum.ToString("X2") + "\r\n";

            checksum = 0;
            foreach (char c in message5)
                checksum ^= Convert.ToByte(c);
            message5 = "$" + message5 + "*" + checksum.ToString("X2") + "\r\n";

            checksum = 0;
            foreach (char c in message6)
                checksum ^= Convert.ToByte(c);
            message6 = "$" + message6 + "*" + checksum.ToString("X2") + "\r\n";

            if (Properties.Settings.Default.PTAK.OutPort1)
                if (SerialPort1.IsOpen)
                {
                    SerialPort1.WriteLine(message1);
                    SerialPort1.WriteLine(message2);
                    SerialPort1.WriteLine(message3);
                    SerialPort1.WriteLine(message4);
                    SerialPort1.WriteLine(message5);
                    SerialPort1.WriteLine(message6);
                }
            if (Properties.Settings.Default.PTAK.OutPort2)
                if (SerialPort2.IsOpen)
                {
                    SerialPort2.WriteLine(message1);
                    SerialPort2.WriteLine(message2);
                    SerialPort2.WriteLine(message3);
                    SerialPort2.WriteLine(message4);
                    SerialPort2.WriteLine(message5);
                    SerialPort2.WriteLine(message6);
                }
            if (Properties.Settings.Default.PTAK.OutPort3)
                if (SerialPort3.IsOpen)
                {
                    SerialPort3.WriteLine(message1);
                    SerialPort3.WriteLine(message2);
                    SerialPort3.WriteLine(message3);
                    SerialPort3.WriteLine(message4);
                    SerialPort3.WriteLine(message5);
                    SerialPort3.WriteLine(message6);
                }
            if (Properties.Settings.Default.PTAK.OutPort4)
                if (SerialPort4.IsOpen)
                {
                    SerialPort4.WriteLine(message1);
                    SerialPort4.WriteLine(message2);
                    SerialPort4.WriteLine(message3);
                    SerialPort4.WriteLine(message4);
                    SerialPort4.WriteLine(message5);
                    SerialPort4.WriteLine(message6);
                }
        }

    }

}
