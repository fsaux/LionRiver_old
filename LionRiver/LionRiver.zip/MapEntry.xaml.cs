﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LionRiver
{
    /// <summary>
    /// Interaction logic for MapEntry.xaml
    /// </summary>
    public partial class MapEntry : UserControl, IComparable<MapEntry>
    {

        public double minLat { get; set; }
        public double maxLat { get; set; }
        public double minLon { get; set; }
        public double maxLon { get; set; }

        public double size { get; set; }

        public string description { get; set; }

        public string filename { get; set; }

        private int t;

        public MapEntry(double lat0, double lon0, double lat1, double lon1, string desc, string fn)
        {
            InitializeComponent();
            
            Background = Brushes.Transparent;

            minLat = lat0;
            maxLat = lat1;
            minLon = lon0;
            maxLon = lon1;

            description = desc;
            filename = fn;

            size = MainWindow.CalcDistance(lat0, lon0, lat1, lon1);
        }

        public int CompareTo(MapEntry other)
        {
            return other.size.CompareTo(this.size);
        }

        private void UserControl_MouseEnter(object sender, MouseEventArgs e)
        {
            Background = Brushes.Green;
            Opacity = 0.3;
        }

        private void UserControl_MouseLeave(object sender, MouseEventArgs e)
        {
            Background = Brushes.Transparent;
            Opacity = 1;
        }

        public event MapEntryEventHandler MapEntryHd;

        protected virtual void OnClick(MapEntryEventArgs e)
        {
            MapEntryEventHandler handler = MapEntryHd;
            if (handler != null)
            {
                // Invokes the delegates.
                handler(this, e);
            }
        }

        private void UserControl_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            t = e.Timestamp;
        }

        private void UserControl_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            int t1 = e.Timestamp - t;
            if (t1 < 200)
            {
                MapEntryEventArgs ea = new MapEntryEventArgs(this.filename);
                OnClick(ea);
            }
        }

    }

    public class MapEntryEventArgs : EventArgs
    {
        private string filename;

        public MapEntryEventArgs(string fn)
        {
            this.filename = fn;
        }

        public string Filename
        {
            get { return filename; }
        }
    }

    public delegate void MapEntryEventHandler(object sender, MapEntryEventArgs e);
}
