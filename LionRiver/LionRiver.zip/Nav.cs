﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Media;

namespace LionRiver
{


    public partial class MainWindow : Window
    {
        public static double ConvertToDeg(string pos)
        {
            double deg = 0, min = 0;
            int i = pos.IndexOf('.');
            if (i != -1)
            {
                deg = double.Parse(pos.Substring(0, i - 2));
                min = double.Parse(pos.Substring(i - 2));
            }
            else
            {
                deg = double.Parse(pos.Substring(0, pos.Length - 2));
            }

            return deg + min / 60;
        }

        public static void CalcPosition(double lat, double lon, double dist, double bearing, ref double nlat, ref double nlon)
        {
            double q;
            lat = lat * Math.PI / 180;
            lon = lon * Math.PI / 180;

            nlat = lat + dist / 6371000 * Math.Cos(bearing * Math.PI / 180);
            double dphi = Math.Log(Math.Tan(nlat / 2 + Math.PI / 4) / Math.Tan(lat / 2 + Math.PI / 4));
            if (bearing == 90 || bearing == 270)
                q = Math.Cos(lat);
            else
                q = (nlat - lat) / dphi;
            double dlon = dist / 6371000 * Math.Sin(bearing * Math.PI / 180) / q;
            nlon = (lon + dlon + Math.PI) % (2 * Math.PI) - Math.PI;

            nlat = nlat * 180 / Math.PI;
            nlon = nlon * 180 / Math.PI;

        }

        public static double CalcBearing(double lat1, double lon1, double lat2, double lon2)
        {
            double brg;

            lat1 = lat1 * Math.PI / 180;
            lon1 = lon1 * Math.PI / 180;
            lat2 = lat2 * Math.PI / 180;
            lon2 = lon2 * Math.PI / 180;

            double dphi = Math.Log(Math.Tan(lat2 / 2 + Math.PI / 4) / Math.Tan(lat1 / 2 + Math.PI / 4));
            brg = Math.Atan2(lon2 - lon1, dphi) * 180 / Math.PI;

            return brg;
        }

        public static double CalcDistance(double lat1, double lon1, double lat2, double lon2)
        {

            double dst,q,tc;

            lat1 = lat1 * Math.PI / 180;
            lon1 = lon1 * Math.PI / 180;
            lat2 = lat2 * Math.PI / 180;
            lon2 = lon2 * Math.PI / 180;

            double dlon_W = (lon2 - lon1) % (2 * Math.PI);
            double dlon_E = (lon1 - lon2) % (2 * Math.PI);
            double dphi = Math.Log(Math.Tan(lat2 / 2 + Math.PI / 4) / Math.Tan(lat1 / 2 + Math.PI / 4));
            if (Math.Abs(lat2 - lat1) < 1e-15)
                q = Math.Cos(lat1);
            else
                q = (lat2 - lat1) / dphi;
            if (dlon_W < dlon_E)
            {
                tc = Math.Atan2(-dlon_W, dphi) % (2 * Math.PI);
                dst = Math.Sqrt(Math.Pow(q * dlon_W, 2) + Math.Pow(lat2 - lat1, 2));
            }
            else
            {
                tc = Math.Atan2(dlon_E, dphi) % (2 * Math.PI);
                dst = Math.Sqrt(Math.Pow(q * dlon_E, 2) + Math.Pow(lat2 - lat1, 2));
            }

            return dst * 6371000;
        }

        public static double ConvertTo180(double ang)
        {
            if (ang > 180) return 360 - ang;
            else
                return ang;
        }
        
        public static bool SetLinePoint1()
        {
            if (LAT.IsValid() && HDT.IsValid())
            {
                CalcPosition(LAT.Val, LON.Val, Properties.Settings.Default.GPSoffsetToBow, HDT.Val, ref p1_lat, ref p1_lon);
                p1_set = true;
                if (p2_set)
                    linebrg = CalcBearing(p1_lat, p1_lon, p2_lat, p2_lon);
                return true;
            }
            else
                return false;
        }

        public static bool SetLinePoint2()
        {
            if (LAT.IsValid() && HDT.IsValid())
            {
                CalcPosition(LAT.Val, LON.Val, Properties.Settings.Default.GPSoffsetToBow, HDT.Val, ref p2_lat, ref p2_lon);
                p2_set = true;
                if (p1_set)
                    linebrg = CalcBearing(p1_lat, p1_lon, p2_lat, p2_lon);
                return true;
            }
            else
                return false;
        }

        public static void CalcNav()
        {

            #region Leg bearing, distance, XTE and VMG
            if (WPT.IsValid() && LAT.IsValid())
            {
                BRG.Val = CalcBearing(LAT.Val, LON.Val, WLAT.Val, WLON.Val);
                BRG.SetValid();
                DST.Val = CalcDistance(LAT.Val, LON.Val, WLAT.Val, WLON.Val) / 1852;
                DST.SetValid();
            }
            else
            {
                if (BRG.IsValid())
                    BRG.Invalidate();
                if (DST.IsValid())
                    DST.Invalidate();
            }

            if (WPT.IsValid() && LWPT.IsValid())
            {
                LEGBRG.Val = CalcBearing(LWLAT.Val, LWLON.Val, WLAT.Val, WLON.Val);
                LEGBRG.SetValid();
            }
            else
            {
                if (LEGBRG.IsValid())
                    LEGBRG.Invalidate();
            }

            if (LWPT.IsValid())
            {
                XTE.Val = Math.Asin(Math.Sin(DST.Val * 1.852 / 6371) * Math.Sin((BRG.Val - LEGBRG.Val) * Math.PI / 180)) * 6371 / 1.852;
                XTE.SetValid();
            }
            else
                if (XTE.IsValid())
                    XTE.Invalidate();

            if (SOG.IsValid() && BRG.IsValid())
            {
                VMGWPT.Val = SOG.Val * Math.Cos((COG.Val - BRG.Val) * Math.PI / 180);
                VMGWPT.SetValid();
            }
            else
            {
                if (VMGWPT.IsValid())
                    VMGWPT.Invalidate();
            } 
            #endregion

            #region True Wind
            if (AWA.IsValid() && SPD.IsValid())
            {
                double Dx = AWS.Val * Math.Cos(AWA.Val * Math.PI / 180) - SPD.Val;
                double Dy = AWS.Val * Math.Sin(AWA.Val * Math.PI / 180);
                TWS.Val = Math.Sqrt(Dx * Dx + Dy * Dy);
                TWS.SetValid();
                TWA.Val = Math.Atan2(Dy, Dx) * 180 / Math.PI;
                TWA.SetValid();
                VMG.Val = SPD.Val * Math.Cos(TWA.Val * Math.PI / 180);
                VMG.SetValid();
            }
            else
            {
                if (TWS.IsValid())
                    TWS.Invalidate();
                if (TWA.IsValid())
                    TWA.Invalidate();
                if (VMG.IsValid())
                    VMG.Invalidate();
            }

            if (TWS.IsValid() && HDT.IsValid())
            {
                TWD.Val = HDT.Val + TWA.Val;
                TWD.SetValid();
            }
            else
            {
                if (TWD.IsValid())
                    TWD.Invalidate();
            } 
            #endregion
         
            #region Drift
            if (SOG.IsValid() && COG.IsValid() && HDT.IsValid())
            {
                double Dx = SOG.Val * Math.Cos(COG.Val * Math.PI / 180) - SPD.Val * Math.Cos(HDT.Val * Math.PI / 180);
                double Dy = SOG.Val * Math.Sin(COG.Val * Math.PI / 180) - SPD.Val * Math.Sin(HDT.Val * Math.PI / 180);
                DRIFT.Val = Math.Sqrt(Dx * Dx + Dy * Dy);
                DRIFT.SetValid();
                SET.Val = Math.Atan2(Dy, Dx) * 180 / Math.PI;
                SET.SetValid();
            }
            else
            {
                if (DRIFT.IsValid())
                    DRIFT.Invalidate();
                if (SET.IsValid())
                    SET.Invalidate();
            } 
            #endregion

            #region Performance
            if (BRG.IsValid() && TWD.IsValid() && SPD.IsValid() && NavPolar.IsLoaded)
            {
                double Angle = Math.Abs((TWD.Val - BRG.Val) % 360);
                if (Angle > 180) Angle = 360 - Angle;

                if (Math.Abs(Angle) <= 45) // Beating
                {
                    PolarPoint p = NavPolar.GetBeatTarget(TWS.Val);
                    TGTSPD.Val = p.SPD;
                    TGTSPD.SetValid();
                    TGTTWA.Val = p.TWA;
                    TGTTWA.SetValid();
                    PERF.Val = VMG.Val / (TGTSPD.Val * Math.Cos(TGTTWA.Val * Math.PI / 180));
                    PERF.SetValid();
                }

                if (Math.Abs(Angle) < 135 && Math.Abs(Angle) > 45) // Reaching
                {
                    TGTSPD.Val = NavPolar.GetTarget(Math.Abs(TWA.Val), TWS.Val);
                    TGTSPD.SetValid();
                    TGTTWA.Val = TWA.Val;
                    TGTTWA.SetValid();
                    PERF.Val = SPD.Val / TGTSPD.Val;
                    PERF.SetValid();
                }

                if (Math.Abs(Angle) >= 135) // Running
                {
                    PolarPoint p = NavPolar.GetRunTarget(TWS.Val);
                    TGTSPD.Val = p.SPD;
                    TGTSPD.SetValid();
                    TGTTWA.Val = p.TWA;
                    TGTTWA.SetValid();
                    PERF.Val = VMG.Val / (TGTSPD.Val * Math.Cos(TGTTWA.Val * Math.PI / 180));
                    PERF.SetValid();
                }

            }
            else
            {
                if (TGTSPD.IsValid())
                    TGTSPD.Invalidate();
                if (TGTTWA.IsValid())
                    TGTTWA.Invalidate();
                if (PERF.IsValid())
                    PERF.Invalidate();
            } 
            #endregion

            #region Line
            if (p1_set && p2_set && LAT.IsValid() && HDT.IsValid())
            {
                double p3_lat = 0, p3_lon = 0;

                CalcPosition(LAT.Val, LON.Val, Properties.Settings.Default.GPSoffsetToBow, HDT.Val, ref p3_lat, ref p3_lon);
                double brg32 = CalcBearing(p3_lat, p3_lon, p2_lat, p2_lon);
                double dst32 = CalcDistance(p3_lat, p3_lon, p2_lat, p2_lon);

                LINEDST.Val = dst32 * Math.Sin((linebrg - brg32) * Math.PI / 180);
                LINEDST.SetValid();
            }
            else
            {
                if (LINEDST.IsValid())
                    LINEDST.Invalidate();
            } 
            #endregion

            #region Route nav
            if (ActiveRoute != null && DST.IsValid())
            {
                if (DST.Val <= Properties.Settings.Default.WptProximity)
                {
                    //(new SoundPlayer(@".\Sounds\BELL7.WAV")).PlaySync();
                    Waypoint wp = ActiveRoute.ActiveRteEntry.ToWpt;
                    wp.SetInactive();
                    int idx = ActiveRoute.RteEntries.IndexOf(ActiveRoute.ActiveRteEntry);
                    if (idx == ActiveRoute.RteEntries.Count - 1) // Last Waypoint in route
                    {
                        WPT.Invalidate();
                        WLAT.Invalidate();
                        WLON.Invalidate();
                        LWPT.Invalidate();
                        LWLAT.Invalidate();
                        LWLON.Invalidate();
                        ActiveRoute.SetInactive();
                        ActiveRoute = null;                        
                    }
                    else
                    {
                        LWPT.FormattedValue = wp.WptName;
                        LWPT.SetValid();
                        LWLAT.Val = wp.Lat;
                        LWLAT.SetValid();
                        LWLON.Val = wp.Lon;
                        LWLON.SetValid();

                        ActiveRoute.ActiveRteEntry = ActiveRoute.RteEntries[idx + 1];
                        wp = ActiveRoute.ActiveRteEntry.ToWpt;
                        wp.SetActive();

                        WPT.FormattedValue = wp.WptName;
                        WPT.SetValid();
                        WLAT.Val = wp.Lat;
                        WLAT.SetValid();
                        WLON.Val = wp.Lon;
                        WLON.SetValid();
                    }


                }
            } 
            #endregion

            #region Laylines

            if (DRIFT.IsValid() && PERF.IsValid() && TWD.IsValid())
            {
                double relset = SET.Val - TWD.Val;
                double dxs = TGTSPD.Val * Math.Cos(TGTTWA.Val * Math.PI / 180) + DRIFT.Val * Math.Cos(relset * Math.PI / 180);
                double dys = TGTSPD.Val * Math.Sin(TGTTWA.Val * Math.PI / 180) + DRIFT.Val * Math.Sin(relset * Math.PI / 180);

                TGTCOGs.Val = Math.Atan2(dys, dxs) * 180 / Math.PI + TWD.Val;
                TGTCOGs.SetValid();
                TGTSOGs.Val = Math.Sqrt(dxs * dxs + dys * dys);
                TGTSOGs.SetValid();

                double dxp = TGTSPD.Val * Math.Cos(-TGTTWA.Val * Math.PI / 180) + DRIFT.Val * Math.Cos(relset * Math.PI / 180);
                double dyp = TGTSPD.Val * Math.Sin(-TGTTWA.Val * Math.PI / 180) + DRIFT.Val * Math.Sin(relset * Math.PI / 180);

                TGTCOGp.Val = Math.Atan2(dyp, dxp) * 180 / Math.PI + TWD.Val;
                TGTCOGp.SetValid();
                TGTSOGp.Val = Math.Sqrt(dxp * dxp + dyp * dyp);
                TGTSOGp.SetValid();
            }
            else
            {
                if (TGTCOGs.IsValid())
                    TGTCOGs.Invalidate();
                if (TGTSOGs.IsValid())
                    TGTSOGs.Invalidate();
                if (TGTCOGp.IsValid())
                    TGTCOGp.Invalidate();
                if (TGTSOGp.IsValid())
                    TGTSOGp.Invalidate();
            }

            #endregion
        }

        public static void CalcLongNav()
        {

            if (TWA.IsValid() && BRG.IsValid() && DRIFT.IsValid() && NavPolar.IsLoaded)
            {
                PolarPoint p = NavPolar.GetTargetVMC(TWS.LongAverage, TWD.LongAverage, BRG.Val, DRIFT.LongAverage, SET.LongAverage);
                TGTVMC.Val = p.SPD;
                TGTVMC.SetValid();
                TGTCTS.Val = TWD.LongAverage + p.TWA;
                TGTCTS.SetValid();
            }
        }

        public static void CalcRouteData()
        {
            if (SelectedRoute != null)
            {
                if (SelectedRoute.RteEntries.Count > 0)
                {
                    Waypoint w0 = SelectedRoute.RteEntries[0].ToWpt;
                    SelectedRoute.RteEntries[0].FromWpt = null;
                    SelectedRoute.RteEntries[0].AccDist = "";
                    SelectedRoute.RteEntries[0].Distance = "";
                    SelectedRoute.RteEntries[0].Bearing = "";
                    SelectedRoute.RteEntries[0].TWA = "";
                    SelectedRoute.RteEntries[0].ETA = "";

                    double accu = 0;

                    for (int i = 1; i < SelectedRoute.RteEntries.Count; i++)
                    {
                        Waypoint w1 = SelectedRoute.RteEntries[i].ToWpt;
                        SelectedRoute.RteEntries[i].FromWpt = w0;
                        double distance = CalcDistance(w0.Lat, w0.Lon, w1.Lat, w1.Lon) / 1852;
                        accu += distance;
                        SelectedRoute.RteEntries[i].AccDist = accu.ToString("#.##");
                        SelectedRoute.RteEntries[i].Distance = distance.ToString("#.##");
                        double bearing = (CalcBearing(w0.Lat, w0.Lon, w1.Lat, w1.Lon) + 360) % 360;
                        SelectedRoute.RteEntries[i].Bearing = bearing.ToString("#");
                        if (TWD.IsValid())
                        {
                            double twangle = ((TWD.LongAverage - bearing) + 360) % 360;
                            if (twangle > 180)
                                twangle = twangle-360;                            
                            SelectedRoute.RteEntries[i].TWA = twangle.ToString("#");
                        }
                        w0 = w1;
                    }
                }
            }
        }

    }
}